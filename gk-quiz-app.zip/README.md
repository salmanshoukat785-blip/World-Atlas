# World Atlas v3.0 (Kotlin + Jetpack Compose)

Offline geography and general-knowledge learning app.

- Splash, welcome note, 3-page onboarding (Skip / Next / Get Started)
- Home: search bar, lessons progress, daily goal, streak, mistakes, topic cards
- Learn: 50 lessons, search, topic filter, saved cards, flash cards, book view, PDF export per lesson
- Quiz: topic + continent + level (Easy/Medium/Hard) filters; modes Practice, Timed, Survival, Blitz, Daily challenge; wrong-answer revision
- Cards: flip flash cards with topic/continent filters
- More: Learning Progress, Score Board, Wrong Answers Revision, Book View, Settings (display mode incl. Sepia, font size, daily goal)
- PDF export for lessons, progress, score board and revision
- No internet permission (fully offline)

Build: upload this zip to GitHub with .github/workflows/build.yml - Actions builds the APK.
