@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package com.gkquiz.app

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

private const val PER_PAGE = 4

/** Reads every lesson like a book: swipe left / right for pages, buttons for chapters. */
@Composable
fun BookReader(startChapter: Int, store: Store, onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var chapter by remember { mutableIntStateOf(startChapter.coerceIn(0, ALL_LESSONS.size - 1)) }
    val lesson = ALL_LESSONS[chapter]
    val pages = remember(chapter) { lesson.items.chunked(PER_PAGE) }
    var done by remember(chapter) { mutableStateOf(lesson.id in store.lessonsDone()) }

    key(chapter) {
        val pager = rememberPagerState(pageCount = { pages.size })

        Column(Modifier.fillMaxSize()) {
            Row(Modifier.padding(start = 4.dp, end = 8.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onBack) { Text("← Back") }
                Column(Modifier.weight(1f)) {
                    Text(
                        "Chapter ${chapter + 1} of ${ALL_LESSONS.size} • ${lesson.cat}",
                        fontSize = 12.sp, color = cs.onBackground.copy(alpha = 0.6f)
                    )
                    Text(
                        "${lesson.emoji} ${lesson.title}",
                        fontSize = 20.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif
                    )
                }
                TextButton(onClick = {
                    PdfExport.exportAndShare(ctx, lesson.title, lessonLines(lesson))
                }) { Text("📄") }
            }

            HorizontalPager(state = pager, modifier = Modifier.weight(1f)) { page ->
                Card(
                    Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 8.dp),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = cs.surface),
                    elevation = CardDefaults.cardElevation(3.dp)
                ) {
                    Column(
                        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        if (page == 0) {
                            Text(lesson.subtitle, fontFamily = FontFamily.Serif, fontSize = 14.sp, color = cs.secondary)
                        }
                        pages[page].forEach { item ->
                            Column {
                                Text(item.term, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                Spacer(Modifier.height(2.dp))
                                Text(item.detail, fontFamily = FontFamily.Serif, fontSize = 15.sp, lineHeight = 22.sp)
                            }
                        }
                        Spacer(Modifier.weight(1f, fill = false))
                        Text(
                            "Page ${page + 1} of ${pages.size}",
                            Modifier.fillMaxWidth(),
                            fontSize = 12.sp,
                            color = cs.onSurface.copy(alpha = 0.5f)
                        )
                    }
                }
            }

            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = { if (chapter > 0) { chapter--; store.lastChapter = chapter } },
                    enabled = chapter > 0
                ) { Text("◀ Prev") }
                if (pager.currentPage == pages.size - 1) {
                    Button(
                        onClick = {
                            val s = store.lessonsDone().toMutableSet()
                            if (done) s.remove(lesson.id) else s.add(lesson.id)
                            store.setLessonsDone(s)
                            done = !done
                        },
                        Modifier.weight(1f)
                    ) { Text(if (done) "✅ Read" else "Mark as read") }
                } else {
                    OutlinedButton(
                        onClick = { scope.launch { pager.animateScrollToPage(pager.currentPage + 1) } },
                        Modifier.weight(1f)
                    ) { Text("Next page ▶") }
                }
                OutlinedButton(
                    onClick = { if (chapter < ALL_LESSONS.size - 1) { chapter++; store.lastChapter = chapter } },
                    enabled = chapter < ALL_LESSONS.size - 1
                ) { Text("Next ▶▶") }
            }
        }
    }
}
