package com.gkquiz.app

private fun w(name: String, kind: String, ocean: String, cont: String, where: String, note: String = "") =
    Water(name, kind, ocean, cont, where, note)

private const val I = "Indian"
private const val A = "Arctic"
private const val S = "Southern"

val WATER_INDIAN: List<Water> = listOf(
    w("Arabian Sea", "Sea", I, "Asia", "India, Pakistan and Oman"),
    w("Andaman Sea", "Sea", I, "Asia", "Myanmar and Thailand coast"),
    w("Laccadive Sea", "Sea", I, "Asia", "India (Lakshadweep), Sri Lanka and Maldives"),
    w("Red Sea", "Sea", I, "Africa / Asia", "Africa and Asia"),
    w("Gulf of Aden", "Gulf", I, "Africa / Asia", "Yemen and Djibouti", "Part of the Arabian Sea"),
    w("Gulf of Aqaba", "Gulf", I, "Asia", "Jordan and Israel (also Egypt, Saudi Arabia)", "Part of the Red Sea"),
    w("Gulf of Mannar", "Gulf", I, "Asia", "Sri Lanka and India", "Part of the Laccadive Sea"),
    w("Gulf of Oman", "Gulf", I, "Asia", "Iran and Oman", "Part of the Arabian Sea"),
    w("Persian Gulf", "Gulf", I, "Asia", "Iran and Saudi Arabia (and other Gulf states)", "Part of the Arabian Sea"),
    w("Gulf of Suez", "Gulf", I, "Africa", "Egypt", "Part of the Red Sea. Lies wholly in Egypt"),
    w("Bay of Bengal", "Bay", I, "Asia", "India, Bangladesh and Myanmar", "Part of the Indian Ocean"),
    w("Palk Bay", "Bay", I, "Asia", "India and Sri Lanka", "Meets the Palk Strait"),
    w("Dutch Bay", "Bay", I, "Asia", "Sri Lanka", "Laccadive Sea"),
    w("Portugal Bay", "Bay", I, "Asia", "Sri Lanka", "Laccadive Sea"),
    w("Puttalam Lagoon", "Lagoon", I, "Asia", "Sri Lanka", "Laccadive Sea"),
    w("Kalpitiya Lagoon", "Lagoon", I, "Asia", "Sri Lanka", "Laccadive Sea"),
    w("Anaiwasal Strait", "Strait", I, "Asia", "Between Kalpitiya Lagoon and Dutch Bay (Sri Lanka)"),
    w("Bab al-Mandab", "Strait", I, "Africa / Asia", "Africa (Djibouti) and Yemen/Saudi side", "Links the Red Sea and the Gulf of Aden / Arabian Sea"),
    w("Strait of Hormuz", "Strait", I, "Asia", "Iran and Oman", "Links the Persian Gulf and the Gulf of Oman"),
    w("Mozambique Channel", "Channel", I, "Africa", "Mozambique and Madagascar"),
    w("Strait of Malacca", "Strait", I, "Asia", "Malaysia and Sumatra (Indonesia)", "Links the Andaman Sea and the South China Sea"),
    w("Palk Strait", "Strait", I, "Asia", "Sri Lanka and India", "Links the Bay of Bengal and the Palk Bay / Laccadive side")
)

val WATER_ARCTIC: List<Water> = listOf(
    w("Beaufort Sea", "Sea", A, "North America", "Alaska and Canada"),
    w("Barents Sea", "Sea", A, "Europe", "Russia and Norway"),
    w("Chukchi Sea", "Sea", A, "Asia / North America", "Alaska and Russia", "Near the International Date Line"),
    w("East Siberian Sea", "Sea", A, "Asia", "Russia, between the Chukchi and Laptev Seas"),
    w("Greenland Sea", "Sea", A, "Europe / North America", "Greenland and Svalbard"),
    w("Laptev Sea", "Sea", A, "Asia", "Russia, between the Kara and East Siberian Seas"),
    w("Kara Sea", "Sea", A, "Asia", "Severnaya Zemlya and Novaya Zemlya (Russia)"),
    w("White Sea", "Sea", A, "Europe", "Russia, an inlet of the Barents Sea"),
    w("Gulf of Ob", "Gulf", A, "Asia", "Russia", "Arm of the Kara Sea"),
    w("Baffin Bay", "Bay", A, "North America", "Baffin Island (Canada) and Greenland"),
    w("Bering Strait", "Strait", A, "Asia / North America", "Asia (Russia) and Alaska (USA)", "Links the Arctic Ocean and the Bering Sea")
)

val WATER_SOUTHERN: List<Water> = listOf(
    w("Bellingshausen Sea", "Sea", S, "Antarctica", "Off West Antarctica"),
    w("Cosmonauts Sea", "Sea", S, "Antarctica", "Off East Antarctica"),
    w("Cooperation Sea", "Sea", S, "Antarctica", "Off East Antarctica"),
    w("Mawson Sea", "Sea", S, "Antarctica", "Off East Antarctica"),
    w("Ross Sea", "Sea", S, "Antarctica", "Deep bay of the Southern Ocean, Ross Ice Shelf"),
    w("Riiser-Larsen Sea", "Sea", S, "Antarctica", "Off East Antarctica"),
    w("Somov Sea", "Sea", S, "Antarctica", "Off East Antarctica"),
    w("Scotia Sea", "Sea", S, "Antarctica", "Between the South Atlantic and Drake Passage"),
    w("Weddell Sea", "Sea", S, "Antarctica", "Off the Antarctic Peninsula")
)

val ALL_WATER: List<Water> = WATER_PACIFIC + WATER_ATLANTIC + WATER_INDIAN + WATER_ARCTIC + WATER_SOUTHERN

class OceanInfo(val name: String, val emoji: String, val facts: List<Pair<String, String>>)

val OCEANS: List<OceanInfo> = listOf(
    OceanInfo("Pacific", "🌊", listOf(
        "Rank" to "Largest and deepest ocean (about 165 million km²)",
        "Divisions" to "North Pacific and South Pacific",
        "Deepest point" to "Challenger Deep, Mariana Trench (about 10,900 m)",
        "Date Line" to "International Date Line crosses it (Bering Sea, Chukchi Sea, Gulf of Anadyr)",
        "Memory code" to "P A I S A = Pacific, Atlantic, Indian, Southern, Arctic (largest to smallest)"
    )),
    OceanInfo("Atlantic", "🌊", listOf(
        "Rank" to "Second largest ocean (about 106 million km²)",
        "Divisions" to "North Atlantic and South Atlantic",
        "Shape" to "S-shaped, separates the Americas from Europe and Africa",
        "Famous sea" to "Sargasso Sea has no land boundary",
        "Marginal seas" to "Mediterranean, Caribbean, North Sea, Baltic, Black Sea"
    )),
    OceanInfo("Indian", "🌊", listOf(
        "Rank" to "Third largest ocean (about 70 million km²)",
        "Named after" to "India",
        "Main seas" to "Arabian Sea, Andaman Sea, Laccadive Sea, Red Sea",
        "Gulfs" to "Aden, Aqaba, Mannar, Oman, Persian, Suez",
        "Important straits" to "Hormuz, Bab al-Mandab, Malacca, Palk, Mozambique Channel"
    )),
    OceanInfo("Southern", "🧊", listOf(
        "Rank" to "Fourth largest ocean",
        "Location" to "Surrounds Antarctica",
        "Seas" to "Bellingshausen, Cosmonauts, Cooperation, Mawson, Ross, Riiser-Larsen, Somov, Scotia, Weddell"
    )),
    OceanInfo("Arctic", "❄️", listOf(
        "Rank" to "Smallest and shallowest ocean",
        "Location" to "Around the North Pole",
        "Seas" to "Beaufort, Barents, Chukchi, East Siberian, Greenland, Laptev, Kara, White",
        "Others" to "Gulf of Ob, Baffin Bay, Bering Strait"
    ))
)
