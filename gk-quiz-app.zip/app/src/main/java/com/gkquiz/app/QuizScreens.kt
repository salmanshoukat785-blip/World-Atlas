@file:OptIn(ExperimentalMaterial3Api::class)

package com.gkquiz.app

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.random.Random

enum class QuizMode(val label: String, val emoji: String, val desc: String) {
    PRACTICE("Practice", "🎯", "Answer at your own pace."),
    TIMED("Timed", "⏱️", "15 seconds for each question. A timeout counts as wrong."),
    SURVIVAL("Survival", "❤️", "You have 3 lives. The quiz ends when they run out."),
    BLITZ("Blitz", "⚡", "60 seconds in total. Answer as many as you can."),
    DAILY("Daily", "📅", "Today's 10 questions, the same for everyone.")
}

val LEVELS = listOf("Easy", "Medium", "Hard")

/** Difficulty of a question, decided by the kind of fact it asks about. */
fun levelOf(f: Fact): String = when (f.grp) {
    "capital", "country", "landlocked", "ocean", "Highest point", "Longest river",
    "Largest country", "Smallest country" -> "Easy"
    "assembly", "rcountries", "founded" -> "Hard"
    else -> "Medium"
}

class QuizPreset(
    val cat: String? = null,
    val cont: String? = null,
    val mistakes: Boolean = false,
    val level: String? = null
)

class Question(val fact: Fact, val options: List<String>)

class QuizSession(val questions: List<Question>, val mode: QuizMode, val label: String)

private fun buildOptions(f: Fact): List<String> {
    f.pool?.let { p ->
        return (p.filter { it != f.a }.shuffled().take(3) + f.a).shuffled()
    }
    val sameGroup = ALL_FACTS.filter { it.cat == f.cat && it.grp == f.grp && it.a != f.a }
    val sameCont = if (f.cont.isNotEmpty()) sameGroup.filter { it.cont == f.cont }.map { it.a }.distinct() else emptyList()
    var wrong = sameCont.shuffled().take(3)
    if (wrong.size < 3) {
        wrong = (wrong + sameGroup.map { it.a }.distinct().shuffled()).distinct().take(3)
    }
    if (wrong.size < 3) {
        wrong = (wrong + ALL_FACTS.filter { it.a != f.a }.map { it.a }.distinct().shuffled()).distinct().take(3)
    }
    return (wrong + f.a).shuffled()
}

fun makeQuestions(facts: List<Fact>, count: Int): List<Question> =
    facts.shuffled().take(count).map { Question(it, buildOptions(it)) }

fun mistakeSession(store: Store): QuizSession? {
    val w = store.wrong()
    val qs = makeQuestions(ALL_FACTS.filter { it.key in w }, 20)
    return if (qs.isEmpty()) null else QuizSession(qs, QuizMode.PRACTICE, "Mistakes revision")
}

// ------------------------------------------------------------------ quiz section

@Composable
fun QuizSection(store: Store, preset: QuizPreset?) {
    val cs = MaterialTheme.colorScheme
    var mode by remember { mutableStateOf(QuizMode.PRACTICE) }
    var cat by remember { mutableStateOf(preset?.cat) }
    var cont by remember { mutableStateOf(preset?.cont) }
    var level by remember { mutableStateOf(preset?.level) }
    var count by remember { mutableIntStateOf(10) }
    var session by remember { mutableStateOf<QuizSession?>(if (preset?.mistakes == true) mistakeSession(store) else null) }
    val s = session

    if (s != null) {
        QuizRun(s, store) { session = null }
        return
    }

    val daily = mode == QuizMode.DAILY
    val available = remember(cat, cont, level) {
        filterFacts(cat, cont).filter { level == null || levelOf(it) == level }
    }
    val wrongCount = remember { store.wrong().size }
    val dailyDone = store.dailyDoneDay == store.today()

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("📝 Quiz", Modifier.padding(horizontal = 16.dp), fontSize = 26.sp, fontWeight = FontWeight.Bold)

        Text("Mode", Modifier.padding(horizontal = 16.dp), fontWeight = FontWeight.SemiBold)
        ChipRow(
            options = QuizMode.values().map { it.name },
            selected = mode.name,
            allLabel = null,
            labelOf = { n -> QuizMode.valueOf(n).let { "${it.emoji} ${it.label}" } }
        ) { n -> if (n != null) mode = QuizMode.valueOf(n) }
        Text(
            mode.desc + if (daily && dailyDone) "  ✅ Completed today" else "",
            Modifier.padding(horizontal = 16.dp),
            fontSize = 13.sp,
            color = cs.onBackground.copy(alpha = 0.7f)
        )

        if (!daily) {
            Text("Level", Modifier.padding(horizontal = 16.dp), fontWeight = FontWeight.SemiBold)
            ChipRow(
                options = LEVELS, selected = level, allLabel = "All levels",
                labelOf = { l -> (if (l == "Easy") "🟢 " else if (l == "Medium") "🟡 " else "🔴 ") + l }
            ) { level = it }

            Text("Topic", Modifier.padding(horizontal = 16.dp), fontWeight = FontWeight.SemiBold)
            ChipRow(
                options = Cats.all, selected = cat, allLabel = "All topics",
                labelOf = { c -> "${topicEmoji[c] ?: ""} $c" }
            ) { cat = it }

            Text("Continent", Modifier.padding(horizontal = 16.dp), fontWeight = FontWeight.SemiBold)
            ChipRow(options = CONT_KEYS, selected = cont, allLabel = "All continents") { cont = it }
        }

        if (mode == QuizMode.PRACTICE || mode == QuizMode.TIMED) {
            Text("Number of questions", Modifier.padding(horizontal = 16.dp), fontWeight = FontWeight.SemiBold)
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(10, 20, 30, 50).forEach { n ->
                    FilterChip(selected = count == n, onClick = { count = n }, label = { Text("$n") })
                }
            }
        }

        if (!daily) {
            Text(
                "${available.size} questions match these filters",
                Modifier.padding(horizontal = 16.dp),
                color = if (available.isEmpty()) Bad else Good,
                fontWeight = FontWeight.SemiBold
            )
            if (available.isEmpty()) {
                Text(
                    "No questions for this combination. Try 'All levels', 'All continents' or another topic.",
                    Modifier.padding(horizontal = 16.dp),
                    fontSize = 13.sp
                )
            }
        }

        Button(
            onClick = {
                val label = listOfNotNull(cat, cont, level).joinToString(" • ").ifEmpty { "All topics" }
                session = when (mode) {
                    QuizMode.PRACTICE, QuizMode.TIMED -> QuizSession(makeQuestions(available, count), mode, label)
                    QuizMode.SURVIVAL -> QuizSession(makeQuestions(available, 100), mode, label)
                    QuizMode.BLITZ -> QuizSession(makeQuestions(available, 200), mode, label)
                    QuizMode.DAILY -> {
                        val facts = ALL_FACTS.shuffled(Random(store.today())).take(10)
                        QuizSession(facts.map { Question(it, buildOptions(it)) }, mode, "Daily challenge")
                    }
                }
            },
            enabled = daily || available.isNotEmpty(),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
        ) { Text("Start ${mode.label}") }

        if (wrongCount > 0) {
            OutlinedButton(
                onClick = { session = mistakeSession(store) },
                Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            ) { Text("🔁 Practice wrong answers ($wrongCount)") }
        }
        Spacer(Modifier.height(8.dp))
    }
}

// ------------------------------------------------------------------ running a quiz

@Composable
fun QuizRun(session: QuizSession, store: Store, onExit: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val questions = session.questions
    val mode = session.mode

    var idx by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    var answered by remember { mutableIntStateOf(0) }
    var lives by remember { mutableIntStateOf(3) }
    var picked by remember { mutableStateOf<String?>(null) }
    var finished by remember { mutableStateOf(false) }
    var secondsLeft by remember { mutableIntStateOf(if (mode == QuizMode.BLITZ) 60 else 15) }

    val q = questions[idx.coerceAtMost(questions.size - 1)]

    fun finish() {
        if (finished) return
        val pct = if (answered == 0) 0 else score * 100 / answered
        store.quizzes = store.quizzes + 1
        store.last = pct
        if (pct > store.best) store.best = pct
        store.addHistory(mode.label, session.label, score, answered)
        if (mode == QuizMode.DAILY) store.dailyDoneDay = store.today()
        finished = true
    }

    fun answer(opt: String) {
        if (picked != null || finished) return
        picked = opt
        val ok = opt == q.fact.a
        answered++
        if (ok) score++ else if (mode == QuizMode.SURVIVAL) lives--
        val w = store.wrong().toMutableSet()
        if (ok) w.remove(q.fact.key) else w.add(q.fact.key)
        store.setWrong(w)
        store.recordActivity()
        store.recordAnswer(ok)
    }

    fun next() {
        val lastOne = idx + 1 >= questions.size
        val dead = mode == QuizMode.SURVIVAL && lives <= 0
        if (lastOne || dead) finish() else {
            idx++
            picked = null
        }
    }

    // per-question countdown (Timed)
    LaunchedEffect(idx) {
        if (mode == QuizMode.TIMED) {
            secondsLeft = 15
            while (secondsLeft > 0 && picked == null && !finished) {
                delay(1000)
                secondsLeft--
            }
            if (picked == null && !finished) answer("")
        }
    }
    // total countdown (Blitz)
    LaunchedEffect(Unit) {
        if (mode == QuizMode.BLITZ) {
            while (secondsLeft > 0 && !finished) {
                delay(1000)
                secondsLeft--
            }
            if (!finished) finish()
        }
    }
    // auto-advance (Blitz)
    LaunchedEffect(picked) {
        if (mode == QuizMode.BLITZ && picked != null && !finished) {
            delay(500)
            next()
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (finished) {
            val pct = if (answered == 0) 0 else score * 100 / answered
            Panel {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("${mode.emoji} ${mode.label} • ${session.label}", fontSize = 13.sp, color = cs.secondary)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        if (pct >= 80) "🏆 Excellent!" else if (pct >= 60) "👍 Good job!" else "💪 Keep practicing!",
                        fontSize = 22.sp, fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(8.dp))
                    Text("$score / $answered", fontSize = 44.sp, fontWeight = FontWeight.Bold, color = cs.primary)
                    Text("$pct%", fontSize = 22.sp, color = if (pct >= 60) Good else Bad)
                    if (mode == QuizMode.SURVIVAL) Text("You answered $answered questions before the end.")
                }
            }
            Button(onClick = onExit, Modifier.fillMaxWidth()) { Text("New Quiz") }
        } else {
            // header: progress + mode status
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    when (mode) {
                        QuizMode.SURVIVAL, QuizMode.BLITZ -> "Question ${idx + 1} • Score $score"
                        else -> "Question ${idx + 1} of ${questions.size}"
                    },
                    Modifier.weight(1f),
                    fontWeight = FontWeight.SemiBold
                )
                when (mode) {
                    QuizMode.TIMED -> Text(
                        "⏱ ${secondsLeft}s", fontWeight = FontWeight.Bold,
                        color = if (secondsLeft <= 5) Bad else cs.primary
                    )
                    QuizMode.BLITZ -> Text(
                        "⚡ ${secondsLeft}s", fontWeight = FontWeight.Bold,
                        color = if (secondsLeft <= 10) Bad else cs.primary
                    )
                    QuizMode.SURVIVAL -> Text("❤️".repeat(lives.coerceAtLeast(0)) + "🖤".repeat((3 - lives).coerceIn(0, 3)))
                    else -> {}
                }
            }
            LinearProgressIndicator(
                progress = {
                    when (mode) {
                        QuizMode.BLITZ -> secondsLeft / 60f
                        QuizMode.TIMED -> secondsLeft / 15f
                        QuizMode.SURVIVAL -> lives.coerceAtLeast(0) / 3f
                        else -> (idx + 1f) / questions.size
                    }
                },
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                color = cs.secondary,
                trackColor = cs.surfaceVariant
            )
            Panel {
                Text(
                    "${topicEmoji[q.fact.cat] ?: ""} ${q.fact.cat} • ${levelOf(q.fact)}",
                    fontSize = 12.sp, color = cs.secondary
                )
                Spacer(Modifier.height(4.dp))
                Text(q.fact.q, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            }
            q.options.forEach { opt ->
                val container = when {
                    picked == null -> cs.primaryContainer
                    opt == q.fact.a -> Good
                    opt == picked -> Bad
                    else -> cs.surfaceVariant
                }
                val content = when {
                    picked == null -> cs.onPrimaryContainer
                    opt == q.fact.a || opt == picked -> Color.White
                    else -> cs.onSurface.copy(alpha = 0.6f)
                }
                Button(
                    onClick = { answer(opt) },
                    Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = container, contentColor = content)
                ) { Text(opt, textAlign = TextAlign.Center, modifier = Modifier.padding(vertical = 4.dp)) }
            }
            if (picked != null) {
                Text(
                    when {
                        picked == q.fact.a -> "✅ Correct!"
                        picked == "" -> "⏱ Time is up. Answer: ${q.fact.a}"
                        else -> "❌ Wrong. Answer: ${q.fact.a}"
                    },
                    color = if (picked == q.fact.a) Good else Bad,
                    fontWeight = FontWeight.Bold
                )
                if (mode != QuizMode.BLITZ) {
                    val last = idx + 1 >= questions.size || (mode == QuizMode.SURVIVAL && lives <= 0)
                    Button(onClick = { next() }, Modifier.fillMaxWidth()) { Text(if (last) "Finish" else "Next") }
                }
            }
            OutlinedButton(onClick = { if (answered > 0) finish() else onExit() }, Modifier.fillMaxWidth()) {
                Text(if (answered > 0) "End quiz" else "Quit")
            }
        }
    }
}
