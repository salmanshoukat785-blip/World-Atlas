@file:OptIn(ExperimentalMaterial3Api::class)

package com.gkquiz.app

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class FlashCard(val front: String, val back: String, val tag: String = "")

/**
 * Tap-to-flip flash cards.
 * If [onResult] is given, the user marks each card as known / need practice.
 * Otherwise the user simply moves with Previous / Next.
 */
@Composable
fun FlipCards(
    cards: List<FlashCard>,
    title: String,
    onResult: ((Int, Boolean) -> Unit)? = null,
    onExit: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    var idx by remember { mutableIntStateOf(0) }
    var flipped by remember { mutableStateOf(false) }
    var gotIt by remember { mutableIntStateOf(0) }
    var missed by remember { mutableIntStateOf(0) }
    val rotation by animateFloatAsState(if (flipped) 180f else 0f, tween(350), label = "flip")
    val density = LocalDensity.current.density

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onExit) { Text("← Back") }
            Text(title, Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1)
        }

        if (idx >= cards.size) {
            Panel {
                Text("🎉 Finished!", fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                if (onResult != null) {
                    Text("I knew it: $gotIt", color = Good, fontSize = 18.sp)
                    Text("Need practice: $missed", color = Bad, fontSize = 18.sp)
                } else {
                    Text("You went through ${cards.size} cards.")
                }
            }
            Button(onClick = { idx = 0; flipped = false; gotIt = 0; missed = 0 }, Modifier.fillMaxWidth()) {
                Text("Start again")
            }
            OutlinedButton(onClick = onExit, Modifier.fillMaxWidth()) { Text("Done") }
            return@Column
        }

        val card = cards[idx]
        Text("Card ${idx + 1} of ${cards.size}", fontWeight = FontWeight.SemiBold)
        LinearProgressIndicator(
            progress = { (idx + 1f) / cards.size },
            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
            color = cs.secondary,
            trackColor = cs.surfaceVariant
        )

        Card(
            onClick = { flipped = !flipped },
            modifier = Modifier
                .fillMaxWidth()
                .height(300.dp)
                .graphicsLayer {
                    rotationY = rotation
                    cameraDistance = 12f * density
                },
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (rotation <= 90f) cs.surface else cs.primaryContainer
            ),
            elevation = CardDefaults.cardElevation(4.dp)
        ) {
            Box(
                Modifier
                    .fillMaxSize()
                    .graphicsLayer { if (rotation > 90f) rotationY = 180f }
                    .padding(20.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    if (card.tag.isNotBlank() && rotation <= 90f) {
                        Text(card.tag, fontSize = 12.sp, color = cs.secondary)
                        Spacer(Modifier.height(8.dp))
                    }
                    if (rotation <= 90f) {
                        Text(card.front, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(16.dp))
                        Text("Tap to flip", fontSize = 12.sp, color = cs.onSurface.copy(alpha = 0.5f))
                    } else {
                        Text(
                            card.back, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                            color = cs.onPrimaryContainer, textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }

        if (onResult != null) {
            if (flipped) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = { onResult(idx, true); gotIt++; flipped = false; idx++ },
                        Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Good, contentColor = Color.White)
                    ) { Text("I knew it") }
                    Button(
                        onClick = { onResult(idx, false); missed++; flipped = false; idx++ },
                        Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Bad, contentColor = Color.White)
                    ) { Text("Need practice") }
                }
            } else {
                Button(onClick = { flipped = true }, Modifier.fillMaxWidth()) { Text("Show answer") }
            }
        } else {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = { if (idx > 0) { idx--; flipped = false } },
                    Modifier.weight(1f),
                    enabled = idx > 0
                ) { Text("← Previous") }
                Button(onClick = { flipped = false; idx++ }, Modifier.weight(1f)) {
                    Text(if (idx + 1 == cards.size) "Finish" else "Next →")
                }
            }
        }
    }
}
