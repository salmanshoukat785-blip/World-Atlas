package com.gkquiz.app

fun contKey(name: String): String = name.substringBefore(" /").trim()

fun isLandlocked(ci: ContinentInfo, x: Country): Boolean =
    ci.landlocked.any { l -> x.name == l || x.name.startsWith("$l (") || x.name.endsWith("($l)") }

private fun shortCapital(s: String): String = s.substringBefore(" (").substringBefore(";").trim()

private val OCEAN_NAMES = listOf("Pacific Ocean", "Atlantic Ocean", "Indian Ocean", "Southern Ocean", "Arctic Ocean")

fun buildGeneratedFacts(): List<Fact> {
    val out = mutableListOf<Fact>()

    // ---------- countries ----------
    for (ci in CONTINENTS) {
        val ck = contKey(ci.name)
        for (x in ci.countries) {
            val n = x.name.substringBefore(" (")
            val ll = isLandlocked(ci, x)
            out += Fact(Cats.COUNTRY, "What is the capital of $n?", shortCapital(x.capital), "capital", ck)
            out += Fact(Cats.COUNTRY, "What is the currency of $n?", x.currency.substringBefore(" ("), "currency", ck)
            out += Fact(Cats.COUNTRY, "Name the legislature / assembly of $n.", x.assembly, "assembly", ck)
            out += Fact(Cats.COUNTRY, "${flagOf(x.iso)}  Which country's flag is this?", n, "country", ck)
            out += Fact(
                Cats.COUNTRY, "Is $n landlocked or does it have a coastline?",
                if (ll) "Landlocked" else "Has a coastline", "landlocked", ck,
                listOf("Landlocked", "Has a coastline")
            )
        }
        for (dp in ci.dependents) {
            out += Fact(Cats.COUNTRY, "${dp.name} belongs to / is administered by?", dp.parent, "parent", ck)
        }
    }

    // ---------- seas, gulfs, straits ----------
    val inland = setOf("Caspian Sea", "Aral Sea", "Dead Sea")
    for (wt in ALL_WATER) {
        out += Fact(Cats.SEA, "Where is the ${wt.name} located?", wt.where, "where", wt.continent)
        if (wt.name !in inland) {
            out += Fact(
                Cats.SEA, "The ${wt.name} belongs to which ocean?", "${wt.ocean} Ocean",
                "ocean", wt.continent, OCEAN_NAMES
            )
        }
    }

    // ---------- rivers ----------
    for (rv in ALL_RIVERS) {
        out += Fact(Cats.RIVER, "Where does the ${rv.name} river (${rv.continent}) end / flow into?", rv.mouth, "mouth", rv.continent)
        out += Fact(Cats.RIVER, "Through which country / countries does the ${rv.name} river (${rv.continent}) flow?", rv.countries, "rcountries", rv.continent)
    }

    // ---------- mountains ----------
    for (mt in MOUNTAINS) {
        out += Fact(Cats.MTN, "In which country / countries is ${mt.name}?", mt.where, "mwhere", mt.continent)
    }

    // ---------- river cities ----------
    for (rc in RIVER_CITIES) {
        for (city in rc.cities) {
            if (city.contains("(") || city.contains("area") || city == "Hudson") continue
            out += Fact(Cats.CITY, "$city lies on the banks of which river?", rc.river, "river", rc.continent)
        }
    }

    // ---------- organizations ----------
    for (og in ORGS) {
        out += Fact(Cats.ORG, "What does ${og.abbr} stand for?", og.full, "full")
        if (!og.hq.startsWith("No fixed")) {
            out += Fact(Cats.ORG, "Where is the headquarters of ${og.abbr}?", og.hq, "hq")
        }
        out += Fact(Cats.ORG, "When was ${og.abbr} founded / established?", og.founded, "founded")
    }

    // ---------- boundary lines ----------
    for (ln in LINES) {
        out += Fact(Cats.LINE, "The ${ln.name} separates or lies between?", ln.between, "between")
    }

    // ---------- continent facts ----------
    val keys = setOf("Highest point", "Longest river", "Largest country", "Smallest country")
    for (ci in CONTINENTS) {
        for ((k, v) in ci.facts) {
            if (k in keys) {
                out += Fact(Cats.CONT, "$k of ${ci.name}?", v.substringBefore(" (").substringBefore(";").trim(), k, contKey(ci.name))
            }
        }
    }
    return out
}

val ALL_FACTS: List<Fact> by lazy { (CORE_FACTS + buildGeneratedFacts()).distinctBy { it.key } }

fun filterFacts(cat: String?, cont: String?): List<Fact> = ALL_FACTS.filter {
    (cat == null || it.cat == cat) && (cont == null || it.cont.contains(cont))
}
