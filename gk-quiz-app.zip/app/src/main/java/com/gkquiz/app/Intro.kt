@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package com.gkquiz.app

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val IntroBrush = Brush.linearGradient(listOf(Color(0xFF0D47A1), Color(0xFF00897B)))

// ------------------------------------------------------------------ splash

@Composable
fun SplashScreen(onDone: () -> Unit) {
    val scaleAnim = remember { Animatable(0.6f) }
    val alphaAnim = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        launch { scaleAnim.animateTo(1f, tween(700)) }
        launch { alphaAnim.animateTo(1f, tween(700)) }
        delay(1900)
        onDone()
    }
    Box(Modifier.fillMaxSize().background(IntroBrush), contentAlignment = Alignment.Center) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.graphicsLayer {
                scaleX = scaleAnim.value
                scaleY = scaleAnim.value
                alpha = alphaAnim.value
            }
        ) {
            Image(
                painterResource(R.drawable.ic_logo),
                contentDescription = "Logo",
                modifier = Modifier.size(120.dp).clip(RoundedCornerShape(28.dp))
            )
            Spacer(Modifier.height(16.dp))
            Text("World Atlas", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
            Text("Explore • Learn • Quiz", color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp)
        }
    }
}

// ------------------------------------------------------------------ welcome

@Composable
fun WelcomeScreen(onContinue: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(IntroBrush).statusBarsPadding().navigationBarsPadding().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image(
            painterResource(R.drawable.ic_logo),
            contentDescription = "Logo",
            modifier = Modifier.size(96.dp).clip(RoundedCornerShape(24.dp))
        )
        Spacer(Modifier.height(16.dp))
        Text("Welcome!", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Text(
            "Your offline guide to the world",
            color = Color.White.copy(alpha = 0.9f),
            fontSize = 16.sp,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        Panel {
            Text("📌 Note", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.height(8.dp))
            Text("• Everything works offline. No internet is needed.")
            Text("• Your progress is saved on this device.")
            Text("• Capitals, currencies and assemblies can change, so check current news for political updates.")
            Text("• Start with Learn, test yourself in Quiz, and revise with flash cards.")
        }
        Spacer(Modifier.height(24.dp))
        Button(onClick = onContinue, Modifier.fillMaxWidth()) { Text("Continue") }
    }
}

// ------------------------------------------------------------------ onboarding

private class OnbPage(val emoji: String, val title: String, val text: String)

private val ONB_PAGES = listOf(
    OnbPage("📚", "Learn by topic", "Lessons on continents, countries with flags, capitals and currencies, oceans, seas, rivers, mountains and organizations."),
    OnbPage("📝", "Quiz yourself", "Choose Easy, Medium or Hard levels, or try Timed, Survival, Blitz and Daily challenges. Wrong answers are saved for revision."),
    OnbPage("📈", "Track your progress", "See your streak, score board and learning progress. Use flash cards, Book view and export your notes as PDF.")
)

@Composable
fun OnboardingScreen(onFinish: () -> Unit) {
    val pager = rememberPagerState(pageCount = { ONB_PAGES.size })
    val scope = rememberCoroutineScope()
    val last = pager.currentPage == ONB_PAGES.size - 1
    val cs = MaterialTheme.colorScheme

    Column(Modifier.fillMaxSize().background(cs.background).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.End) {
            if (!last) TextButton(onClick = onFinish) { Text("Skip") }
            else Spacer(Modifier.height(48.dp))
        }
        HorizontalPager(state = pager, modifier = Modifier.weight(1f)) { page ->
            val p = ONB_PAGES[page]
            Column(
                Modifier.fillMaxSize().padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(p.emoji, fontSize = 84.sp)
                Spacer(Modifier.height(24.dp))
                Text(p.title, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = cs.primary, textAlign = TextAlign.Center)
                Spacer(Modifier.height(12.dp))
                Text(p.text, fontSize = 16.sp, textAlign = TextAlign.Center)
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ONB_PAGES.indices.forEach { i ->
                    Box(
                        Modifier.size(if (i == pager.currentPage) 12.dp else 8.dp)
                            .clip(CircleShape)
                            .background(if (i == pager.currentPage) cs.primary else cs.surfaceVariant)
                    )
                }
            }
            Button(onClick = {
                if (last) onFinish() else scope.launch { pager.animateScrollToPage(pager.currentPage + 1) }
            }) { Text(if (last) "Get Started" else "Next") }
        }
    }
}
