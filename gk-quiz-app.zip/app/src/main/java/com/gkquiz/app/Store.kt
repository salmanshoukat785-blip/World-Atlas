package com.gkquiz.app

import android.content.Context
import java.util.TimeZone

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("gk", Context.MODE_PRIVATE)

    var quizzes: Int
        get() = p.getInt("quizzes", 0)
        set(v) { p.edit().putInt("quizzes", v).apply() }

    var best: Int
        get() = p.getInt("best", 0)
        set(v) { p.edit().putInt("best", v).apply() }

    var last: Int
        get() = p.getInt("last", -1)
        set(v) { p.edit().putInt("last", v).apply() }

    /** 0 = system, 1 = light, 2 = dark */
    var theme: Int
        get() = p.getInt("theme", 0)
        set(v) { p.edit().putInt("theme", v).apply() }

    var dailyGoal: Int
        get() = p.getInt("goal", 10)
        set(v) { p.edit().putInt("goal", v).apply() }

    fun known(): Set<String> = p.getStringSet("known", emptySet())!!.toSet()
    fun setKnown(s: Set<String>) { p.edit().putStringSet("known", s).apply() }

    fun bookmarks(): Set<String> = p.getStringSet("bookmarks", emptySet())!!.toSet()
    fun setBookmarks(s: Set<String>) { p.edit().putStringSet("bookmarks", s).apply() }

    fun wrong(): Set<String> = p.getStringSet("wrong", emptySet())!!.toSet()
    fun setWrong(s: Set<String>) { p.edit().putStringSet("wrong", s).apply() }

    fun lessonsDone(): Set<String> = p.getStringSet("lessonsDone", emptySet())!!.toSet()
    fun setLessonsDone(s: Set<String>) { p.edit().putStringSet("lessonsDone", s).apply() }

    fun savedItems(): Set<String> = p.getStringSet("savedItems", emptySet())!!.toSet()
    fun setSavedItems(s: Set<String>) { p.edit().putStringSet("savedItems", s).apply() }

    fun today(): Long {
        val now = System.currentTimeMillis()
        return (now + TimeZone.getDefault().getOffset(now)) / 86_400_000L
    }

    /** Call once for every question answered / card reviewed. */
    fun recordActivity() {
        val t = today()
        val l = p.getLong("lastDay", -1L)
        var s = p.getInt("streak", 0)
        var c = p.getInt("todayCount", 0)
        if (l != t) {
            s = if (l == t - 1) s + 1 else 1
            c = 0
        }
        c++
        p.edit().putLong("lastDay", t).putInt("streak", s).putInt("todayCount", c)
            .putInt("bestStreak", maxOf(p.getInt("bestStreak", 0), s))
            .putInt("act_$t", p.getInt("act_$t", 0) + 1).apply()
    }

    fun currentStreak(): Int {
        val l = p.getLong("lastDay", -1L)
        return if (l < 0 || l < today() - 1) 0 else p.getInt("streak", 0)
    }

    fun todayDone(): Int =
        if (p.getLong("lastDay", -1L) == today()) p.getInt("todayCount", 0) else 0

    /** Clears progress but keeps theme, daily goal, font size and onboarding flag. */
    fun resetProgress() {
        val th = theme
        val g = dailyGoal
        val f = fontLevel
        val ob = onboarded
        p.edit().clear().putInt("theme", th).putInt("goal", g).putInt("fontLevel", f).putBoolean("onboarded", ob).apply()
    }

    // ---------- intro / display ----------
    var onboarded: Boolean
        get() = p.getBoolean("onboarded", false)
        set(v) { p.edit().putBoolean("onboarded", v).apply() }

    /** 0 small, 1 normal, 2 large, 3 extra large */
    var fontLevel: Int
        get() = p.getInt("fontLevel", 1)
        set(v) { p.edit().putInt("fontLevel", v).apply() }

    fun fontScale(): Float = when (fontLevel) {
        0 -> 0.85f
        2 -> 1.15f
        3 -> 1.3f
        else -> 1f
    }

    // ---------- statistics ----------
    var totalAnswered: Int
        get() = p.getInt("totalAnswered", 0)
        set(v) { p.edit().putInt("totalAnswered", v).apply() }

    var totalCorrect: Int
        get() = p.getInt("totalCorrect", 0)
        set(v) { p.edit().putInt("totalCorrect", v).apply() }

    fun recordAnswer(ok: Boolean) {
        totalAnswered += 1
        if (ok) totalCorrect += 1
    }

    fun bestStreak(): Int = p.getInt("bestStreak", 0)

    fun activityFor(day: Long): Int = p.getInt("act_$day", 0)

    var dailyDoneDay: Long
        get() = p.getLong("dailyDoneDay", -1L)
        set(v) { p.edit().putLong("dailyDoneDay", v).apply() }

    /** Entry format: time|mode|topic|score|total */
    fun addHistory(mode: String, topic: String, score: Int, total: Int) {
        val line = "${System.currentTimeMillis()}|$mode|$topic|$score|$total"
        val l = history().toMutableList()
        l.add(0, line)
        p.edit().putString("history", l.take(60).joinToString("\n")).apply()
    }

    fun history(): List<String> =
        (p.getString("history", "") ?: "").split("\n").filter { it.isNotBlank() }

    var lastChapter: Int
        get() = p.getInt("lastChapter", 0)
        set(v) { p.edit().putInt("lastChapter", v).apply() }
}
