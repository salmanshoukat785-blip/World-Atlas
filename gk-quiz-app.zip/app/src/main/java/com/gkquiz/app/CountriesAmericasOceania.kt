package com.gkquiz.app

val NA_COUNTRIES = listOf(
    c("Antigua and Barbuda", "AG", "St. John's", "East Caribbean Dollar", "Parliament (Senate + House of Representatives)"),
    c("Bahamas", "BS", "Nassau", "Bahamian Dollar", "Parliament (Senate + House of Assembly)"),
    c("Barbados", "BB", "Bridgetown", "Barbadian Dollar", "Parliament (Senate + House of Assembly)"),
    c("Belize", "BZ", "Belmopan", "Belize Dollar", "National Assembly"),
    c("Canada", "CA", "Ottawa", "Canadian Dollar", "Parliament (House of Commons + Senate)"),
    c("Costa Rica", "CR", "San José", "Costa Rican Colón", "Legislative Assembly"),
    c("Cuba", "CU", "Havana", "Cuban Peso", "National Assembly of People's Power"),
    c("Dominica", "DM", "Roseau", "East Caribbean Dollar", "House of Assembly"),
    c("Dominican Republic", "DO", "Santo Domingo", "Dominican Peso", "Congress (Senate + Chamber of Deputies)"),
    c("El Salvador", "SV", "San Salvador", "US Dollar", "Legislative Assembly"),
    c("Grenada", "GD", "St. George's", "East Caribbean Dollar", "Parliament (Senate + House of Representatives)"),
    c("Guatemala", "GT", "Guatemala City", "Quetzal", "Congress of the Republic"),
    c("Haiti", "HT", "Port-au-Prince", "Gourde", "Parliament (not functioning)"),
    c("Honduras", "HN", "Tegucigalpa", "Lempira", "National Congress"),
    c("Jamaica", "JM", "Kingston", "Jamaican Dollar", "Parliament (Senate + House of Representatives)"),
    c("Mexico", "MX", "Mexico City", "Mexican Peso", "Congress of the Union (Chamber of Deputies + Senate)"),
    c("Nicaragua", "NI", "Managua", "Córdoba", "National Assembly"),
    c("Panama", "PA", "Panama City", "Balboa (US Dollar also used)", "National Assembly"),
    c("Saint Kitts and Nevis", "KN", "Basseterre", "East Caribbean Dollar", "National Assembly"),
    c("Saint Lucia", "LC", "Castries", "East Caribbean Dollar", "Parliament (Senate + House of Assembly)"),
    c("Saint Vincent and the Grenadines", "VC", "Kingstown", "East Caribbean Dollar", "House of Assembly"),
    c("Trinidad and Tobago", "TT", "Port of Spain", "Trinidad and Tobago Dollar", "Parliament (Senate + House of Representatives)"),
    c("United States of America", "US", "Washington, D.C.", "US Dollar", "Congress (Senate + House of Representatives)")
)

val NA_DEPENDENT = listOf(
    d("Anguilla", "UK"), d("Aruba", "Netherlands (constituent country)"), d("Bermuda", "UK"),
    d("Bonaire", "Netherlands (special municipality)"), d("British Virgin Islands", "UK"),
    d("Cayman Islands", "UK"), d("Curaçao", "Netherlands (constituent country)"),
    d("Clipperton Island", "France"), d("Greenland", "Denmark (self-governing)", "Largest island in the world"),
    d("Guadeloupe", "France"), d("Montserrat", "UK"), d("Martinique", "France"),
    d("Saint Pierre and Miquelon", "France"), d("Navassa Island", "USA"),
    d("Puerto Rico", "USA (unincorporated territory)"), d("Saint Barthélemy", "France"),
    d("Saba", "Netherlands (special municipality)"), d("Saint Martin", "France"),
    d("Sint Maarten", "Netherlands (constituent country)"),
    d("San Andrés and Providencia", "Colombia (department)"),
    d("Sint Eustatius", "Netherlands (special municipality)"),
    d("Turks and Caicos Islands", "UK"), d("US Virgin Islands", "USA"),
    d("Venezuelan Federal Dependencies / Nueva Esparta", "Venezuela", "Venezuelan islands and state in the Caribbean")
)

val SA_COUNTRIES = listOf(
    c("Argentina", "AR", "Buenos Aires", "Argentine Peso", "National Congress (Senate + Chamber of Deputies)"),
    c("Bolivia", "BO", "Sucre (constitutional); La Paz (seat of government)", "Boliviano", "Plurinational Legislative Assembly"),
    c("Brazil", "BR", "Brasília", "Real", "National Congress (Federal Senate + Chamber of Deputies)"),
    c("Chile", "CL", "Santiago", "Chilean Peso", "National Congress (seat: Valparaíso)"),
    c("Colombia", "CO", "Bogotá", "Colombian Peso", "Congress (Senate + House of Representatives)"),
    c("Ecuador", "EC", "Quito", "US Dollar", "National Assembly"),
    c("Guyana", "GY", "Georgetown", "Guyanese Dollar", "National Assembly"),
    c("Paraguay", "PY", "Asunción", "Guaraní", "Congress (Senate + Chamber of Deputies)"),
    c("Peru", "PE", "Lima", "Sol", "Congress of the Republic"),
    c("Suriname", "SR", "Paramaribo", "Surinamese Dollar", "National Assembly"),
    c("Uruguay", "UY", "Montevideo", "Uruguayan Peso", "General Assembly (Senate + Chamber of Representatives)"),
    c("Venezuela", "VE", "Caracas", "Bolívar", "National Assembly")
)

val SA_DEPENDENT = listOf(
    d("French Guiana", "France (overseas department)"),
    d("Falkland Islands", "UK Overseas Territory (disputed with Argentina)")
)

val OCEANIA_COUNTRIES = listOf(
    c("Australia", "AU", "Canberra", "Australian Dollar", "Parliament (Senate + House of Representatives)"),
    c("Fiji", "FJ", "Suva", "Fijian Dollar", "Parliament of Fiji"),
    c("Kiribati", "KI", "South Tarawa", "Australian Dollar", "Maneaba ni Maungatabu"),
    c("Marshall Islands", "MH", "Majuro", "US Dollar", "Nitijela"),
    c("Micronesia (FSM)", "FM", "Palikir", "US Dollar", "Congress of the FSM"),
    c("Nauru", "NR", "Yaren (de facto)", "Australian Dollar", "Parliament of Nauru"),
    c("New Zealand", "NZ", "Wellington", "New Zealand Dollar", "Parliament (House of Representatives)"),
    c("Palau", "PW", "Ngerulmud", "US Dollar", "Olbiil Era Kelulau"),
    c("Papua New Guinea", "PG", "Port Moresby", "Kina", "National Parliament"),
    c("Samoa", "WS", "Apia", "Tala", "Legislative Assembly (Fono)"),
    c("Solomon Islands", "SB", "Honiara", "Solomon Islands Dollar", "National Parliament"),
    c("Tonga", "TO", "Nukuʻalofa", "Paʻanga", "Legislative Assembly"),
    c("Tuvalu", "TV", "Funafuti", "Australian Dollar / Tuvaluan Dollar", "Parliament (Fale i Fono)"),
    c("Vanuatu", "VU", "Port Vila", "Vatu", "Parliament of Vanuatu")
)

val OCEANIA_DEPENDENT = listOf(
    d("American Samoa", "USA"), d("Cook Islands", "New Zealand (free association)"),
    d("French Polynesia", "France"), d("Guam", "USA"), d("New Caledonia", "France"),
    d("Niue", "New Zealand (free association)"), d("Norfolk Island", "Australia"),
    d("Northern Mariana Islands", "USA"), d("Pitcairn Islands", "UK"),
    d("Tokelau", "New Zealand"), d("Wake Island", "USA"),
    d("Wallis and Futuna", "France")
)
