package com.gkquiz.app

class LItem(val term: String, val detail: String, val tag: String = "")

class Lesson(
    val id: String,
    val cat: String,
    val emoji: String,
    val title: String,
    val subtitle: String,
    val items: List<LItem>,
    /** Quiz category / continent opened by "Quiz this lesson". */
    val quizCat: String = cat,
    val quizCont: String? = null
)

val CONT_KEYS = listOf("Asia", "Europe", "Africa", "North America", "South America", "Australia", "Antarctica")

private fun waterDetail(w: Water): String {
    val head = "${w.kind} • ${w.ocean} Ocean • ${w.continent}\n${w.where}"
    return if (w.note.isBlank()) head else "$head\n${w.note}"
}

private fun countryDetail(x: Country): String =
    "🏛 Capital: ${x.capital}\n💰 Currency: ${x.currency}\n🏢 Assembly: ${x.assembly}"

private fun orgDetail(o: Org): String {
    val sb = StringBuilder(o.full)
    sb.append("\nFounded: ").append(o.founded)
    sb.append("\nHeadquarters: ").append(o.hq)
    if (o.extra.isNotBlank()) sb.append("\n").append(o.extra)
    return sb.toString()
}

fun buildLessons(): List<Lesson> {
    val out = mutableListOf<Lesson>()

    // ================= Continents =================
    for (ci in CONTINENTS) {
        val items = mutableListOf<LItem>()
        ci.facts.forEach { items += LItem(it.first, it.second, "Facts") }
        if (ci.landlocked.isNotEmpty()) {
            items += LItem("Landlocked countries (${ci.landlocked.size})", ci.landlocked.joinToString(", "), "Landlocked")
        }
        if (ci.memoryCodes.isNotEmpty()) {
            items += LItem("Memory codes", ci.memoryCodes.joinToString("\n"), "Memory codes")
        }
        if (ci.countries.isNotEmpty()) {
            items += LItem("Countries (${ci.countries.size})", ci.countries.joinToString(", ") { it.name.substringBefore(" (") }, "Countries")
        }
        if (ci.dependents.isNotEmpty()) {
            items += LItem("Dependent territories (${ci.dependents.size})", ci.dependents.joinToString(", ") { it.name }, "Dependent")
        }
        out += Lesson(
            "cont-${ci.name}", Cats.CONT, ci.emoji, ci.name,
            if (ci.countries.isEmpty()) "Ice continent" else "${ci.countries.size} countries",
            items, Cats.CONT, contKey(ci.name)
        )
    }

    // ================= Countries (per continent) =================
    for (ci in CONTINENTS) {
        if (ci.countries.isEmpty()) continue
        val items = ci.countries.sortedBy { it.name }.map {
            LItem(
                "${flagOf(it.iso)}  ${it.name}", countryDetail(it),
                if (isLandlocked(ci, it)) "Landlocked" else "Coastal"
            )
        }
        out += Lesson(
            "country-${ci.name}", Cats.COUNTRY, ci.emoji, "Countries of ${ci.name}",
            "Capital, currency, flag and assembly",
            items, Cats.COUNTRY, contKey(ci.name)
        )
    }

    // Landlocked countries (all continents)
    run {
        val items = mutableListOf<LItem>()
        for (ci in CONTINENTS) {
            ci.countries.filter { isLandlocked(ci, it) }.sortedBy { it.name }.forEach {
                items += LItem(
                    "${flagOf(it.iso)}  ${it.name}",
                    "${contKey(ci.name)} • Capital: ${it.capital}",
                    contKey(ci.name)
                )
            }
        }
        out += Lesson(
            "country-landlocked", Cats.COUNTRY, "🏔️", "Landlocked countries",
            "Asia 12 • Europe 14 • Africa 16 • South America 2",
            items, Cats.COUNTRY, null
        )
    }

    // Dependent territories
    run {
        val items = mutableListOf<LItem>()
        for (ci in CONTINENTS) {
            ci.dependents.forEach {
                val note = if (it.note.isBlank()) "" else "\n${it.note}"
                items += LItem(it.name, "Belongs to: ${it.parent}$note", contKey(ci.name))
            }
        }
        out += Lesson(
            "country-dependent", Cats.COUNTRY, "🏝️", "Dependent territories",
            "Islands and territories of the world",
            items, Cats.COUNTRY, null
        )
    }

    // ================= Oceans =================
    for (oc in OCEANS) {
        val items = mutableListOf<LItem>()
        oc.facts.forEach { items += LItem(it.first, it.second, "Facts") }
        val ws = ALL_WATER.filter { it.ocean == oc.name }
        ws.forEach { items += LItem(it.name, waterDetail(it), it.kind) }
        out += Lesson(
            "ocean-${oc.name}", Cats.OCEAN, oc.emoji, "${oc.name} Ocean",
            "${ws.size} seas, gulfs, bays and straits",
            items, Cats.SEA, null
        )
    }

    // ================= Seas by continent =================
    for (key in CONT_KEYS) {
        val ws = ALL_WATER.filter { it.continent.contains(key) }
        if (ws.isEmpty()) continue
        out += Lesson(
            "sea-$key", Cats.SEA, "🌊", "Seas of $key",
            "${ws.size} water bodies with countries",
            ws.map { LItem(it.name, waterDetail(it), it.kind) },
            Cats.SEA, key
        )
    }
    run {
        val ws = ALL_WATER.filter { it.kind == "Strait" || it.kind == "Channel" }
        out += Lesson(
            "sea-straits", Cats.SEA, "🚢", "Straits and channels of the world",
            "${ws.size} straits: what they connect and separate",
            ws.map { LItem(it.name, waterDetail(it), it.ocean) },
            Cats.SEA, null
        )
    }

    // ================= Rivers =================
    for (key in listOf("Asia", "Europe", "Africa", "Australia", "North America", "South America")) {
        val rs = ALL_RIVERS.filter { it.continent == key }
        out += Lesson(
            "river-$key", Cats.RIVER, "🏞️", "Rivers of $key",
            "${rs.size} rivers: countries and where they end",
            rs.map {
                val note = if (it.note.isBlank()) "" else "\n${it.note}"
                LItem(it.name, "Flows through: ${it.countries}\nFlows into: ${it.mouth}$note")
            },
            Cats.RIVER, key
        )
    }

    // ================= Mountains =================
    for (key in listOf("Asia", "Africa", "Europe", "Australia", "South America", "North America")) {
        val ms = MOUNTAINS.filter { it.continent == key }
        out += Lesson(
            "mtn-$key", Cats.MTN, "⛰️", "Mountains of $key",
            "${ms.size} ranges and where they lie",
            ms.map {
                val note = if (it.note.isBlank()) "" else "\n${it.note}"
                LItem(it.name, "${it.where}$note")
            },
            Cats.MTN, key
        )
    }

    // ================= Cities on river banks =================
    for (key in listOf("Asia", "Europe", "North America", "South America", "Africa")) {
        val rc = RIVER_CITIES.filter { it.continent == key }
        out += Lesson(
            "city-$key", Cats.CITY, "🏙️", "River cities of $key",
            "${rc.size} rivers and the cities on their banks",
            rc.map {
                val note = if (it.note.isBlank()) "" else "\n${it.note}"
                LItem(it.river, it.cities.joinToString(" • ") + note)
            },
            Cats.CITY, key
        )
    }

    // ================= Organizations =================
    val groupTitles = listOf(
        "United Nations" to "UN and its agencies",
        "Regional groups" to "Regional and political groups",
        "Defence and finance" to "Defence, trade and finance"
    )
    for ((g, title) in groupTitles) {
        val os = ORGS.filter { it.group == g }
        out += Lesson(
            "org-$g", Cats.ORG, "🏛️", title, "${os.size} organizations: founding date and headquarters",
            os.map { LItem(it.abbr, orgDetail(it)) }, Cats.ORG, null
        )
    }
    out += Lesson(
        "org-abbr", Cats.ORG, "🔤", "Abbreviations (full forms)",
        "${ORGS.size} short forms and what they stand for",
        ORGS.sortedBy { it.abbr }.map { LItem(it.abbr, it.full) }, Cats.ORG, null
    )

    // ================= Boundary lines =================
    out += Lesson(
        "line-all", Cats.LINE, "🗺️", "Boundary lines and parallels",
        "${LINES.size} famous lines and the countries they divide",
        LINES.map {
            val note = if (it.note.isBlank()) "" else "\n${it.note}"
            LItem(it.name, "${it.between}$note")
        },
        Cats.LINE, null
    )

    return out
}

val ALL_LESSONS: List<Lesson> by lazy { buildLessons() }
