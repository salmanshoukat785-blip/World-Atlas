package com.gkquiz.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = Store(this)
        setContent {
            var themeMode by remember { mutableIntStateOf(store.theme) }
            var fontLevel by remember { mutableIntStateOf(store.fontLevel) }
            // 0 splash, 1 welcome, 2 onboarding, 3 app
            var stage by remember { mutableIntStateOf(0) }

            val base = LocalDensity.current
            val scale = when (fontLevel) { 0 -> 0.85f; 2 -> 1.15f; 3 -> 1.3f; else -> 1f }
            CompositionLocalProvider(LocalDensity provides Density(base.density, base.fontScale * scale)) {
                GKTheme(themeMode) {
                    when (stage) {
                        0 -> SplashScreen { stage = if (store.onboarded) 3 else 1 }
                        1 -> WelcomeScreen { stage = 2 }
                        2 -> OnboardingScreen {
                            store.onboarded = true
                            stage = 3
                        }
                        else -> AppRoot(
                            store = store,
                            themeMode = themeMode,
                            onTheme = { themeMode = it; store.theme = it },
                            fontLevel = fontLevel,
                            onFont = { fontLevel = it; store.fontLevel = it },
                            onReplayIntro = { stage = 1 }
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppRoot(
    store: Store,
    themeMode: Int,
    onTheme: (Int) -> Unit,
    fontLevel: Int,
    onFont: (Int) -> Unit,
    onReplayIntro: () -> Unit
) {
    var tab by remember { mutableIntStateOf(0) }
    var keyN by remember { mutableIntStateOf(0) }
    var learnCat by remember { mutableStateOf<String?>(null) }
    var learnQuery by remember { mutableStateOf("") }
    var openLesson by remember { mutableStateOf<Lesson?>(null) }
    var quizPreset by remember { mutableStateOf<QuizPreset?>(null) }
    var sub by remember { mutableStateOf<String?>(null) }
    var bookStart by remember { mutableIntStateOf(0) }

    val tabs = listOf("🏠" to "Home", "📚" to "Learn", "📝" to "Quiz", "🃏" to "Cards", "⋯" to "More")

    fun go(t: Int) {
        tab = t
        sub = null
        keyN++
    }

    fun openBook(start: Int) {
        bookStart = start
        sub = "book"
        keyN++
    }

    BackHandler(enabled = tab != 0 || openLesson != null || sub != null) {
        if (sub != null) {
            sub = null
            keyN++
        } else if (openLesson != null) {
            openLesson = null
            keyN++
        } else {
            learnCat = null
            learnQuery = ""
            quizPreset = null
            go(0)
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = {
                            learnCat = null
                            learnQuery = ""
                            quizPreset = null
                            openLesson = null
                            go(i)
                        },
                        icon = { Text(t.first, fontSize = 20.sp) },
                        label = { Text(t.second, fontSize = 11.sp) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            key(tab, keyN) {
                val s = sub
                when {
                    s == "progress" -> ProgressScreen(store) { sub = null; keyN++ }
                    s == "score" -> ScoreBoardScreen(store) { sub = null; keyN++ }
                    s == "revision" -> RevisionScreen(
                        store = store,
                        onBack = { sub = null; keyN++ },
                        onPractice = { quizPreset = QuizPreset(mistakes = true); go(2) }
                    )
                    s == "book" -> BookReader(bookStart, store) { sub = null; keyN++ }
                    s == "settings" -> SettingsScreen(
                        store = store,
                        themeMode = themeMode,
                        onTheme = onTheme,
                        fontLevel = fontLevel,
                        onFont = onFont,
                        onReplayIntro = onReplayIntro,
                        onBack = { sub = null; keyN++ }
                    )
                    tab == 0 -> HomeScreen(
                        store = store,
                        onOpenLesson = { l -> openLesson = l; go(1) },
                        onLearnCat = { c -> learnCat = c; openLesson = null; go(1) },
                        onQuiz = { quizPreset = null; go(2) },
                        onTest = { go(3) },
                        onMistakes = { quizPreset = QuizPreset(mistakes = true); go(2) },
                        onSearch = { q -> learnQuery = q; learnCat = null; openLesson = null; go(1) },
                        onProgress = { sub = "progress"; keyN++ },
                        onScore = { sub = "score"; keyN++ }
                    )
                    tab == 1 -> {
                        val l = openLesson
                        if (l != null) {
                            LessonDetail(
                                lesson = l,
                                store = store,
                                onBack = { openLesson = null; keyN++ },
                                onQuiz = {
                                    quizPreset = QuizPreset(cat = l.quizCat, cont = l.quizCont)
                                    openLesson = null
                                    go(2)
                                },
                                onBook = { openBook(ALL_LESSONS.indexOf(l).coerceAtLeast(0)) }
                            )
                        } else {
                            LearnHome(
                                store = store,
                                initialCat = learnCat,
                                initialQuery = learnQuery,
                                onBook = { openBook(store.lastChapter) }
                            ) { picked -> openLesson = picked; keyN++ }
                        }
                    }
                    tab == 2 -> QuizSection(store, quizPreset)
                    tab == 3 -> SelfTestSection(store)
                    else -> MoreScreen { id ->
                        if (id == "book") openBook(store.lastChapter) else { sub = id; keyN++ }
                    }
                }
            }
        }
    }
}
