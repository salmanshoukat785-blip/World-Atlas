@file:OptIn(ExperimentalMaterial3Api::class)

package com.gkquiz.app

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
private fun ScreenHeader(title: String, onBack: () -> Unit) {
    Row(Modifier.padding(start = 4.dp, end = 16.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = onBack) { Text("← Back") }
        Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    }
}

// ------------------------------------------------------------------ More

@Composable
fun MoreScreen(onOpen: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val items = listOf(
        Triple("progress", "📈 Learning Progress", "Lessons, cards, accuracy and weekly activity"),
        Triple("score", "🏆 Score Board", "Your quiz results and best scores"),
        Triple("revision", "🔁 Wrong Answers Revision", "Review and practice what you missed"),
        Triple("book", "📖 Book View", "Read all lessons page by page"),
        Triple("settings", "⚙️ Settings", "Theme, font size, daily goal and more")
    )
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("More", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        items.forEach { (id, title, sub) ->
            Card(
                onClick = { onOpen(id) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = cs.surface),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text(sub, fontSize = 13.sp, color = cs.onSurface.copy(alpha = 0.65f))
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Learning progress

@Composable
fun ProgressScreen(store: Store, onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    val done = remember { store.lessonsDone() }
    val known = remember { store.known() }
    val lessonsDone = ALL_LESSONS.count { it.id in done }
    val cardsKnown = ALL_FACTS.count { it.key in known }
    val acc = if (store.totalAnswered == 0) 0 else store.totalCorrect * 100 / store.totalAnswered
    val today = store.today()
    val days = (6 downTo 0).map { today - it }
    val counts = days.map { store.activityFor(it) }
    val maxCount = (counts.maxOrNull() ?: 0).coerceAtLeast(1)
    val names = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("📈 Learning Progress", onBack)
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Panel {
                Text("Overall", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Spacer(Modifier.height(8.dp))
                BarRow("Lessons completed", lessonsDone, ALL_LESSONS.size)
                Spacer(Modifier.height(8.dp))
                BarRow("Cards learned", cardsKnown, ALL_FACTS.size)
                Spacer(Modifier.height(10.dp))
                Text("Quiz accuracy: $acc%  (${store.totalCorrect} of ${store.totalAnswered})")
                Text("Streak: ${store.currentStreak()} days  •  Best: ${store.bestStreak()} days")
            }

            Panel {
                Text("Last 7 days", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Spacer(Modifier.height(10.dp))
                Row(
                    Modifier.fillMaxWidth().height(120.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.Bottom
                ) {
                    days.forEachIndexed { i, d ->
                        val c = counts[i]
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("$c", fontSize = 11.sp)
                            Box(
                                Modifier
                                    .width(26.dp)
                                    .height((6 + 70 * c / maxCount).dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (c > 0) cs.secondary else cs.surfaceVariant)
                            )
                            Text(names[((d + 3) % 7).toInt()], fontSize = 11.sp)
                        }
                    }
                }
            }

            Panel {
                Text("By topic", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Spacer(Modifier.height(8.dp))
                Cats.all.forEach { c ->
                    val ls = ALL_LESSONS.filter { it.cat == c }
                    val fs = ALL_FACTS.filter { it.cat == c }
                    Text("${topicEmoji[c] ?: ""} $c", fontWeight = FontWeight.SemiBold)
                    BarRow("Lessons", ls.count { it.id in done }, ls.size)
                    BarRow("Cards", fs.count { it.key in known }, fs.size)
                    Spacer(Modifier.height(10.dp))
                }
            }

            Button(
                onClick = { PdfExport.exportAndShare(ctx, "progress", progressLines(store)) },
                Modifier.fillMaxWidth()
            ) { Text("📄 Export progress as PDF") }
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun BarRow(label: String, value: Int, total: Int) {
    val cs = MaterialTheme.colorScheme
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.width(120.dp), fontSize = 13.sp)
        LinearProgressIndicator(
            progress = { if (total == 0) 0f else value.toFloat() / total },
            modifier = Modifier.weight(1f).height(8.dp).clip(RoundedCornerShape(4.dp)),
            color = cs.secondary,
            trackColor = cs.surfaceVariant
        )
        Text("  $value/$total", fontSize = 12.sp)
    }
}

// ------------------------------------------------------------------ Score board

@Composable
fun ScoreBoardScreen(store: Store, onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    val fmt = remember { SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()) }
    val rows = remember {
        store.history().mapNotNull { h ->
            val p = h.split("|")
            if (p.size < 5) null else listOf(p[0], p[1], p[2], p[3], p[4])
        }
    }
    val avg = if (rows.isEmpty()) 0 else rows.map {
        val t = it[4].toIntOrNull() ?: 0
        if (t == 0) 0 else (it[3].toIntOrNull() ?: 0) * 100 / t
    }.average().toInt()

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("🏆 Score Board", onBack)
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ScoreTile("Quizzes", store.quizzes.toString(), Modifier.weight(1f))
                ScoreTile("Best", "${store.best}%", Modifier.weight(1f))
                ScoreTile("Average", "$avg%", Modifier.weight(1f))
            }
            Text("Recent quizzes", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            if (rows.isEmpty()) {
                Text("No quizzes yet. Play one from the Quiz tab.")
            }
            rows.forEach { r ->
                val score = r[3].toIntOrNull() ?: 0
                val total = r[4].toIntOrNull() ?: 0
                val pct = if (total == 0) 0 else score * 100 / total
                Card(
                    Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = cs.surface)
                ) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("${r[1]} • ${r[2]}", fontWeight = FontWeight.SemiBold)
                            Text(
                                fmt.format(Date(r[0].toLongOrNull() ?: 0L)),
                                fontSize = 12.sp, color = cs.onSurface.copy(alpha = 0.6f)
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("$score / $total", fontWeight = FontWeight.Bold)
                            Text("$pct%", color = if (pct >= 60) Good else Bad, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            Button(
                onClick = { PdfExport.exportAndShare(ctx, "score_board", scoreLines(store)) },
                Modifier.fillMaxWidth()
            ) { Text("📄 Export score board as PDF") }
        }
    }
}

@Composable
private fun ScoreTile(label: String, value: String, modifier: Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(12.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Text(label, fontSize = 12.sp)
        }
    }
}

// ------------------------------------------------------------------ Wrong answers revision

@Composable
fun RevisionScreen(store: Store, onBack: () -> Unit, onPractice: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    var wrong by remember { mutableStateOf(store.wrong()) }
    val facts = remember(wrong) { ALL_FACTS.filter { it.key in wrong } }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("🔁 Wrong Answers", onBack)
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("${facts.size} questions to revise", fontWeight = FontWeight.SemiBold)
            if (facts.isEmpty()) {
                Text("Nothing to revise. Questions you miss in a quiz appear here, and leave this list when you answer them correctly.")
            } else {
                Button(onClick = onPractice, Modifier.fillMaxWidth()) { Text("Practice these questions") }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(
                        onClick = { PdfExport.exportAndShare(ctx, "revision", revisionLines(store)) },
                        Modifier.weight(1f)
                    ) { Text("📄 Export PDF") }
                    OutlinedButton(
                        onClick = { store.setWrong(emptySet()); wrong = emptySet() },
                        Modifier.weight(1f)
                    ) { Text("Clear all", color = Bad) }
                }
            }
            facts.forEach { f ->
                Card(
                    Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = cs.surface)
                ) {
                    Row(Modifier.padding(start = 14.dp, top = 10.dp, bottom = 10.dp, end = 4.dp), verticalAlignment = Alignment.Top) {
                        Column(Modifier.weight(1f)) {
                            Text("${topicEmoji[f.cat] ?: ""} ${f.cat}", fontSize = 11.sp, color = cs.secondary)
                            Text(f.q, fontWeight = FontWeight.SemiBold)
                            Text(f.a, color = cs.primary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                        TextButton(onClick = {
                            val w = wrong.toMutableSet()
                            w.remove(f.key)
                            store.setWrong(w)
                            wrong = w
                        }) { Text("✔ Got it") }
                    }
                }
            }
        }
    }
}
