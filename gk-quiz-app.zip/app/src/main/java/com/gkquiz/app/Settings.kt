@file:OptIn(ExperimentalMaterial3Api::class)

package com.gkquiz.app

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ------------------------------------------------------------------ self test (flash cards)

@Composable
fun SelfTestSection(store: Store) {
    var cat by remember { mutableStateOf<String?>(null) }
    var cont by remember { mutableStateOf<String?>(null) }
    var mode by remember { mutableIntStateOf(0) }
    var deck by remember { mutableStateOf<List<Fact>?>(null) }
    var empty by remember { mutableStateOf(false) }
    val d = deck

    if (d != null) {
        val cards = d.map { f -> FlashCard(f.q, f.a, "${topicEmoji[f.cat] ?: ""} ${f.cat}") }
        FlipCards(
            cards = cards,
            title = "Flash cards",
            onResult = { i, knew ->
                val f = d[i]
                val k = store.known().toMutableSet()
                if (knew) k.add(f.key) else k.remove(f.key)
                store.setKnown(k)
                store.recordActivity()
            },
            onExit = { deck = null }
        )
        return
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("🃏 Flash Cards", Modifier.padding(horizontal = 16.dp), fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("Tap a card to flip it, then mark what you know.", Modifier.padding(horizontal = 16.dp))
        Text("Topic", Modifier.padding(horizontal = 16.dp), fontWeight = FontWeight.SemiBold)
        ChipRow(
            options = Cats.all, selected = cat, allLabel = "All topics",
            labelOf = { c -> "${topicEmoji[c] ?: ""} $c" }
        ) { cat = it; empty = false }
        Text("Continent", Modifier.padding(horizontal = 16.dp), fontWeight = FontWeight.SemiBold)
        ChipRow(options = CONT_KEYS, selected = cont, allLabel = "All continents") { cont = it; empty = false }
        Text("Cards", Modifier.padding(horizontal = 16.dp), fontWeight = FontWeight.SemiBold)
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("All", "Not learned", "★ Saved").forEachIndexed { i, label ->
                FilterChip(selected = mode == i, onClick = { mode = i; empty = false }, label = { Text(label) })
            }
        }
        Button(
            onClick = {
                val known = store.known()
                val saved = store.bookmarks()
                val l = filterFacts(cat, cont).filter { f ->
                    when (mode) {
                        1 -> f.key !in known
                        2 -> f.key in saved
                        else -> true
                    }
                }.shuffled().take(50)
                if (l.isEmpty()) {
                    empty = true
                } else {
                    empty = false
                    deck = l
                }
            },
            Modifier.fillMaxWidth().padding(horizontal = 16.dp)
        ) { Text("Start (up to 50 cards)") }
        if (empty) {
            Text(
                "No cards match this choice. Try another topic, continent or filter.",
                Modifier.padding(horizontal = 16.dp),
                color = Bad
            )
        }
    }
}

// ------------------------------------------------------------------ settings

@Composable
fun SettingsScreen(
    store: Store,
    themeMode: Int,
    onTheme: (Int) -> Unit,
    fontLevel: Int,
    onFont: (Int) -> Unit,
    onReplayIntro: () -> Unit,
    onBack: () -> Unit
) {
    var goal by remember { mutableIntStateOf(store.dailyGoal) }
    var confirm by remember { mutableStateOf(false) }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            confirmButton = {
                TextButton(onClick = { store.resetProgress(); confirm = false }) { Text("Reset") }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } },
            title = { Text("Reset progress?") },
            text = { Text("Scores, completed lessons, learned cards, saved items, mistakes and streak will be cleared.") }
        )
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(start = 4.dp, top = 8.dp)) {
            TextButton(onClick = onBack) { Text("← Back") }
        }
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("⚙️ Settings", fontSize = 26.sp, fontWeight = FontWeight.Bold)

            Panel {
                Text("🎨 Display mode", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("System", "Light", "Dark", "Sepia").forEachIndexed { i, label ->
                        FilterChip(selected = themeMode == i, onClick = { onTheme(i) }, label = { Text(label) })
                    }
                }
            }

            Panel {
                Text("🔠 Font size", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Small", "Normal", "Large", "XL").forEachIndexed { i, label ->
                        FilterChip(selected = fontLevel == i, onClick = { onFont(i) }, label = { Text(label) })
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text("Sample text: the quick brown fox jumps over the lazy dog.")
            }

            Panel {
                Text("🎯 Daily goal (questions)", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(5, 10, 20, 30).forEach { n ->
                        FilterChip(
                            selected = goal == n,
                            onClick = { goal = n; store.dailyGoal = n },
                            label = { Text("$n") }
                        )
                    }
                }
            }

            Panel {
                Text("📴 Offline data", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Works completely offline. No internet permission is used. " +
                        "${ALL_LESSONS.size} lessons and ${ALL_FACTS.size} quiz questions are stored inside the app."
                )
            }

            Panel {
                Text("ℹ️ About the data", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Lessons cover continents, countries, oceans, seas, rivers, mountains, river cities, organizations and boundary lines. " +
                        "Capitals, currencies and assemblies can change, so check current news for political changes."
                )
            }

            OutlinedButton(onClick = onReplayIntro, Modifier.fillMaxWidth()) { Text("Show welcome tour again") }
            OutlinedButton(onClick = { confirm = true }, Modifier.fillMaxWidth()) {
                Text("Reset progress", color = Bad)
            }
            Text(
                "World Atlas • v3.0",
                Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
            )
        }
    }
}
