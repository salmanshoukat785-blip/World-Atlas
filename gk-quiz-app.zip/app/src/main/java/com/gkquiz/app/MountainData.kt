package com.gkquiz.app

private fun m(cont: String, name: String, where: String, note: String = "") =
    Mountain(name, cont, where, note)

private const val AS = "Asia"
private const val AF = "Africa"
private const val EU = "Europe"
private const val AU = "Australia"
private const val SA = "South America"
private const val NA = "North America"

val MOUNTAINS: List<Mountain> = listOf(
    // ---------------- Asia ----------------
    m(AS, "Altai", "Russia, Kazakhstan, China, Mongolia"),
    m(AS, "Alay", "Kyrgyzstan, Tajikistan"),
    m(AS, "Alborz", "Iran"),
    m(AS, "Aravalli", "India", "Oldest mountain system"),
    m(AS, "Ararat", "Turkey"),
    m(AS, "Barisan", "Sumatra, Indonesia"),
    m(AS, "Chersky", "Siberia, Russia"),
    m(AS, "Caucasus", "Armenia, Azerbaijan, Georgia, Iran, Turkey, Russia"),
    m(AS, "Himalaya", "Bhutan, China, Nepal, India, Pakistan", "Youngest and highest mountain system in the world. Mount Everest 8,848.86 m"),
    m(AS, "Hindu Kush", "Afghanistan, Pakistan"),
    m(AS, "Japanese Alps", "Japan"),
    m(AS, "Karakoram", "Afghanistan, China, India, Pakistan, Tajikistan", "Home of K2"),
    m(AS, "Kunlun", "China"),
    m(AS, "Kirthar", "Pakistan"),
    m(AS, "Koh-e-Sultan", "Pakistan"),
    m(AS, "Pamir", "Tajikistan, Kyrgyzstan, Afghanistan, Pakistan, China"),
    m(AS, "Sayan", "Siberia, Russia"),
    m(AS, "Spin Ghar (Koh-e-Safed)", "Afghanistan, Pakistan"),
    m(AS, "Tian Shan", "China, Kazakhstan, Kyrgyzstan, Uzbekistan, Tajikistan"),
    m(AS, "Western Ghats", "India"),
    m(AS, "Zagros", "Iran, Iraq, Turkey"),

    // ---------------- Africa ----------------
    m(AF, "Atlas", "Morocco, Algeria, Tunisia"),
    m(AF, "Cameroon (Mount Cameroon)", "Cameroon"),
    m(AF, "Drakensberg", "South Africa, Lesotho"),
    m(AF, "Elgon", "Uganda, Kenya"),
    m(AF, "Ethiopian Highlands", "Ethiopia"),
    m(AF, "Hoggar (Ahaggar)", "Algeria"),
    m(AF, "Kilimanjaro", "Tanzania", "Highest peak in Africa"),
    m(AF, "Mount Kenya", "Kenya", "2nd highest in Africa"),
    m(AF, "Mitumba", "DR Congo"),
    m(AF, "Marrah", "Sudan"),
    m(AF, "Rwenzori", "Uganda, DR Congo"),
    m(AF, "Swartberg", "South Africa"),

    // ---------------- Europe ----------------
    m(EU, "Alps", "Austria, France, Germany, Italy, Liechtenstein, Slovenia, Switzerland", "Largest mountain range in Europe"),
    m(EU, "Apennines", "Italy, San Marino"),
    m(EU, "Balkan", "Bulgaria, Serbia"),
    m(EU, "Baetic", "Spain"),
    m(EU, "Corsica", "France", "An island with mountains (not a range)"),
    m(EU, "Cantabrian", "Spain"),
    m(EU, "Crete", "Greece", "An island with mountains (not a range)"),
    m(EU, "Dinaric Alps", "Albania, Bosnia, Italy, Croatia, Montenegro, Slovenia"),
    m(EU, "Carpathian", "Czech Republic, Poland, Austria, Slovakia, Ukraine and others"),
    m(EU, "Pennine Alps", "Switzerland, Italy"),
    m(EU, "Pyrenees", "Spain, France, Andorra"),
    m(EU, "Pindus", "Greece, Albania"),
    m(EU, "Rila", "Bulgaria"),
    m(EU, "Scandinavian", "Norway, Sweden, Finland"),
    m(EU, "Sicily", "Italy", "An island with mountains (not a range)"),
    m(EU, "Sudetes", "Czech Republic, Poland, Germany"),
    m(EU, "Ural", "Russia, Kazakhstan", "Boundary between Europe and Asia"),

    // ---------------- Australia / Oceania ----------------
    m(AU, "Bismarck Range", "Papua New Guinea"),
    m(AU, "Brindabella", "Australia"),
    m(AU, "Blue Mountains", "Australia"),
    m(AU, "Darling Scarp", "Australia"),
    m(AU, "Finisterre", "Papua New Guinea"),
    m(AU, "Flinders Ranges", "Australia"),
    m(AU, "Hamersley Range", "Australia"),
    m(AU, "Great Dividing Range", "Australia"),
    m(AU, "MacDonnell Ranges", "Australia"),
    m(AU, "Musgrave Ranges", "Australia"),
    m(AU, "Owen Stanley Range", "Papua New Guinea"),
    m(AU, "Southern Alps", "New Zealand"),
    m(AU, "Stirling Range", "Australia"),
    m(AU, "West Coast Range", "Tasmania, Australia"),

    // ---------------- South America ----------------
    m(SA, "Andes", "Argentina, Bolivia, Chile, Colombia, Ecuador, Peru, Venezuela", "Longest mountain range in the world"),
    m(SA, "Espinhaço", "Brazil"),
    m(SA, "Mantiqueira", "Brazil"),
    m(SA, "Sierra Nevada de Santa Marta", "Colombia"),
    m(SA, "Serranía de la Macarena", "Colombia"),
    m(SA, "Sierras de Córdoba", "Argentina"),
    m("Antarctica", "Prince Charles Mountains", "Antarctica"),

    // ---------------- North America ----------------
    m(NA, "Alaska Peninsula range", "United States"),
    m(NA, "Alaska Range", "United States", "Contains Denali"),
    m(NA, "Appalachian", "United States, Canada"),
    m(NA, "Brooks Range", "United States"),
    m(NA, "Black Mountains", "Mexico"),
    m(NA, "Chigmit", "United States"),
    m(NA, "Chugach", "United States"),
    m(NA, "Canadian Rockies", "Canada"),
    m(NA, "Columbia Mountains", "United States, Canada"),
    m(NA, "Cascade Range", "United States, Canada"),
    m(NA, "Coast Mountains", "United States, Canada"),
    m(NA, "Cordillera de Talamanca", "Costa Rica, Panama"),
    m(NA, "Davis Mountains", "United States"),
    m(NA, "Greenland highlands", "Greenland", "Island of Greenland: an island with highlands, not a single range"),
    m(NA, "Olympic Mountains", "United States"),
    m(NA, "Orange Coast ranges", "United States"),
    m(NA, "Rocky Mountains", "United States, Canada", "Largest in North America"),
    m(NA, "Saint Elias", "United States, Canada"),
    m(NA, "Sierra Nevada", "United States"),
    m(NA, "Sierra Madre de Chiapas", "Mexico, Guatemala, El Salvador, Honduras"),
    m(NA, "Spring Mountains", "United States"),
    m(NA, "San Bernardino Mountains", "California, United States"),
    m(NA, "Sacramento Mountains", "New Mexico, United States"),
    m(NA, "Trans-Mexican Volcanic Belt", "Mexico")
)

private fun rc(river: String, cont: String, vararg cities: String, note: String = "") =
    RiverCities(river, cont, cities.toList(), note)

val RIVER_CITIES: List<RiverCities> = listOf(
    // ---------------- Asia ----------------
    rc("Barada River", "Asia", "Damascus"),
    rc("Chao Phraya River", "Asia", "Bangkok"),
    rc("Chenab River", "Asia", "Sialkot", "Kot Mithan", "Wazirabad"),
    rc("Ganga River", "Asia", "Patna", "Kanpur", "Allahabad (Prayagraj)", "Varanasi", "Haridwar", "Bhagalpur"),
    rc("Indus River", "Asia", "Skardu (Sakardu)", "Dera Ismail Khan", "Swabi", "Sukkur", "Dasu", "Besham", "Hyderabad", "Attock", "Rohri"),
    rc("Yamuna (Jamuna) River", "Asia", "Delhi", "Agra", "Prayagraj", "Yamunanagar", "Mathura", "Noida", "Etawah", "Firozabad", "Kalpi", "Hamirpur"),
    rc("Jhelum River", "Asia", "Srinagar", "Jhelum", "Muzaffarabad"),
    rc("Karnaphuli River", "Asia", "Chittagong"),
    rc("Ravi River", "Asia", "Lahore", "Pathankot", "Kamalia"),
    rc("Shatt al-Arab River", "Asia", "Abadan", "Basra", "Khorramshahr"),
    rc("Sutlej River", "Asia", "Bahawalpur"),
    rc("Sumida River", "Asia", "Tokyo"),
    rc("Tigris River", "Asia", "Samarra", "Mosul", "Diyarbakır", "Baghdad"),
    rc("Yangtze River", "Asia", "Shanghai", "Wuxi", "Suzhou"),

    // ---------------- Europe ----------------
    rc("Amstel River", "Europe", "Amsterdam", "Nieuwveen"),
    rc("Avon River", "Europe", "Bath", "Bristol"),
    rc("Arno River", "Europe", "Florence", "Pisa"),
    rc("Danube River", "Europe", "Budapest", "Belgrade", "Vienna", "Bratislava", "Ruse", "Ulm", "Novi Sad", "Linz", "Vukovar", "Szekszárd", "Passau"),
    rc("Liffey River", "Europe", "Dublin", "Leixlip", "Kildare area"),
    rc("Rhine River", "Europe", "Bonn", "Cologne", "Rotterdam", "Basel", "Duisburg"),
    rc("Seine River", "Europe", "Paris", "Le Havre"),
    rc("Spree River", "Europe", "Berlin", "Bautzen", "Cottbus", "Köpenick", "Lübbenau", "Spremberg"),
    rc("Thames River", "Europe", "London", "Oxford", "Reading", "Windsor", "Henley"),
    rc("Tiber River", "Europe", "Rome", "Perugia"),
    rc("Volga River", "Europe", "Nizhny Novgorod", "Volgograd", "Ulyanovsk", "Rzhev", "Zavolzhye", "Yaroslavl", "Saratov", "Kazan", "Astrakhan"),
    rc("Senne River", "Europe", "Brussels"),
    rc("Vistula River", "Europe", "Warsaw", "Wisła", "Kraków", "Dobrzyń"),

    // ---------------- Americas ----------------
    rc("Amazon River", "South America", "Manaus", "Santarém", "Iquitos", "Macapá", "Leticia"),
    rc("Hudson River", "North America", "New York", "Albany", "Yonkers", "Beacon", "Kingston", "Troy", "Glens Falls", "Hudson", "Newburgh"),
    rc("Ottawa River", "North America", "Ottawa", "Montreal (at the mouth)"),

    // ---------------- Africa ----------------
    rc("Nile River", "Africa", "Cairo", "Aswan", "Alexandria", "Khartoum", "Juba", "Jinja")
)
