package com.gkquiz.app

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Builds a simple text PDF with android.graphics.pdf.PdfDocument (no extra libraries).
 * Line prefixes: "# " big title, "## " heading, anything else normal text.
 */
object PdfExport {
    private const val PAGE_W = 595
    private const val PAGE_H = 842
    private const val MARGIN = 44f

    /** The PDF font cannot draw emoji and symbols, so they are removed. */
    private fun clean(s: String): String =
        s.filter { c -> !(c.isSurrogate() || c.code in 0x2190..0x2BFF || c.code == 0xFE0F || c.code == 0x200D) }.trim()

    private fun wrap(text: String, paint: Paint, width: Float): List<String> {
        val out = mutableListOf<String>()
        var line = ""
        for (word in text.split(" ")) {
            val trial = if (line.isEmpty()) word else "$line $word"
            if (paint.measureText(trial) <= width) {
                line = trial
            } else {
                if (line.isNotEmpty()) out.add(line)
                line = word
            }
        }
        if (line.isNotEmpty()) out.add(line)
        return out
    }

    fun createPdf(ctx: Context, fileName: String, lines: List<String>): File {
        val doc = PdfDocument()
        val normal = Paint().apply { textSize = 11.5f; color = 0xFF222222.toInt(); isAntiAlias = true }
        val heading = Paint().apply {
            textSize = 13.5f; color = 0xFF0D47A1.toInt(); isAntiAlias = true
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val big = Paint().apply {
            textSize = 22f; color = 0xFF0D47A1.toInt(); isAntiAlias = true
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val footer = Paint().apply { textSize = 9f; color = 0xFF777777.toInt(); isAntiAlias = true }
        val maxW = PAGE_W - 2 * MARGIN

        var pageNo = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(PAGE_W, PAGE_H, pageNo).create())
        var y = MARGIN + 10f

        fun closePage() {
            page.canvas.drawText("World Atlas  -  page $pageNo", MARGIN, PAGE_H - 24f, footer)
            doc.finishPage(page)
        }

        fun ensure(space: Float) {
            if (y + space > PAGE_H - 50f) {
                closePage()
                pageNo++
                page = doc.startPage(PdfDocument.PageInfo.Builder(PAGE_W, PAGE_H, pageNo).create())
                y = MARGIN + 10f
            }
        }

        for (raw in lines) {
            val isBig = raw.startsWith("# ")
            val isHead = raw.startsWith("## ")
            val text = clean(if (isBig) raw.drop(2) else if (isHead) raw.drop(3) else raw)
            if (text.isEmpty()) {
                y += 8f
                continue
            }
            val paint = if (isBig) big else if (isHead) heading else normal
            val lead = paint.textSize * 1.35f
            if (isHead) y += 6f
            for (part in wrap(text, paint, maxW)) {
                ensure(lead)
                y += lead
                page.canvas.drawText(part, MARGIN, y, paint)
            }
            if (isBig) y += 8f
        }
        closePage()

        val dir = File(ctx.cacheDir, "exports").apply { mkdirs() }
        val file = File(dir, fileName)
        file.outputStream().use { doc.writeTo(it) }
        doc.close()
        return file
    }

    private fun saveToDownloads(ctx: Context, file: File): Boolean {
        if (Build.VERSION.SDK_INT < 29) return false
        return try {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, file.name)
                put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return false
            ctx.contentResolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Creates the PDF, saves a copy in Downloads (Android 10+) and opens the share sheet. */
    fun exportAndShare(ctx: Context, baseName: String, lines: List<String>) {
        try {
            val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
            val safe = baseName.replace(Regex("[^A-Za-z0-9]+"), "_").trim('_').ifEmpty { "export" }
            val file = createPdf(ctx, "WorldAtlas_${safe}_$stamp.pdf", lines)
            val saved = saveToDownloads(ctx, file)
            if (saved) Toast.makeText(ctx, "PDF saved in Downloads", Toast.LENGTH_SHORT).show()

            val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            ctx.startActivity(Intent.createChooser(send, "Share or save PDF").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            Toast.makeText(ctx, "Could not create the PDF", Toast.LENGTH_SHORT).show()
        }
    }
}

// ------------------------------------------------------------------ report builders

fun lessonLines(l: Lesson): List<String> {
    val out = mutableListOf("# ${l.title}", l.subtitle, "")
    for (item in l.items) {
        out += "## ${item.term}"
        item.detail.split("\n").forEach { d -> out += d }
    }
    return out
}

fun progressLines(store: Store): List<String> {
    val done = store.lessonsDone()
    val known = store.known()
    val out = mutableListOf("# Learning progress", "")
    out += "Lessons completed: ${ALL_LESSONS.count { it.id in done }} of ${ALL_LESSONS.size}"
    out += "Cards learned: ${ALL_FACTS.count { it.key in known }} of ${ALL_FACTS.size}"
    val acc = if (store.totalAnswered == 0) 0 else store.totalCorrect * 100 / store.totalAnswered
    out += "Quiz accuracy: $acc% (${store.totalCorrect} of ${store.totalAnswered} answers)"
    out += "Current streak: ${store.currentStreak()} days (best ${store.bestStreak()})"
    out += ""
    out += "## By topic"
    for (c in Cats.all) {
        val ls = ALL_LESSONS.filter { it.cat == c }
        val fs = ALL_FACTS.filter { it.cat == c }
        out += "$c: ${ls.count { it.id in done }}/${ls.size} lessons, ${fs.count { it.key in known }}/${fs.size} cards"
    }
    return out
}

fun scoreLines(store: Store): List<String> {
    val fmt = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault())
    val out = mutableListOf("# Score board", "")
    out += "Quizzes played: ${store.quizzes}   Best score: ${store.best}%"
    out += ""
    out += "## Recent quizzes"
    for (h in store.history()) {
        val p = h.split("|")
        if (p.size < 5) continue
        val score = p[3].toIntOrNull() ?: 0
        val total = p[4].toIntOrNull() ?: 0
        val pct = if (total == 0) 0 else score * 100 / total
        out += "${fmt.format(Date(p[0].toLongOrNull() ?: 0L))} - ${p[1]} - ${p[2]}: $score/$total ($pct%)"
    }
    return out
}

fun revisionLines(store: Store): List<String> {
    val w = store.wrong()
    val out = mutableListOf("# Wrong answers revision", "")
    val facts = ALL_FACTS.filter { it.key in w }
    out += "${facts.size} questions to revise"
    out += ""
    for (f in facts) {
        out += "## ${f.q}"
        out += "Answer: ${f.a}"
    }
    return out
}
