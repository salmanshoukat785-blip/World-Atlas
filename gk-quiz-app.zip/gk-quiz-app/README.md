# World Atlas v2.0 (Kotlin + Jetpack Compose)

Offline geography and general-knowledge learning app.

- Home: lessons progress, daily goal, streak, mistakes, topic cards
- Learn: 50 lessons (continents, countries with flag/capital/currency/assembly, oceans, seas by continent, rivers, mountains, river cities, organizations, boundary lines), search + topic filter + saved cards
- Quiz (separate section): topic + continent filters, 10/20/30/50 questions, mistakes review
- Self Test: flashcards with topic/continent filters
- Theme, daily goal, no internet permission

Edit data: files in app/src/main/java/com/gkquiz/app (Countries*.kt, Water*.kt, Rivers*.kt, MountainData.kt, OrgData.kt ...).
Build: upload this zip to GitHub with .github/workflows/build.yml - Actions builds the APK.
