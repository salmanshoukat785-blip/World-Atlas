# World Atlas (Kotlin + Jetpack Compose)

Offline GK / Geography learning app.

Features: Dashboard (streak, daily goal, topic progress, fact of the day), Learn (search + topic filter + save),
Quiz (10/20/30 MCQs, mistakes review), Self Test (flashcards), Dark/Light theme, Settings. No internet needed.

## APK banane ka tareeqa
Is zip ko GitHub repo me upload karein (bina kholay) + `.github/workflows/build.yml`. Actions khud APK bana dega.
Questions edit karne ke liye: `app/src/main/java/com/gkquiz/app/Data.kt`.
