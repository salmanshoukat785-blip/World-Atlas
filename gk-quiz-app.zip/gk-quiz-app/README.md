# GK Quiz (Kotlin + Jetpack Compose)

Dashboard, Quiz (10 MCQs) and Self Test (flashcards) built from the Continents & Oceans study sheet.

## APK banane ka tareeqa (GitHub Actions)

1. github.com par naya repository banayein (e.g. `gk-quiz-app`).
2. Is folder ki saari files us repo me upload karein (`.github` folder samet).
3. Repo ke **Actions** tab me jayein, "Build APK" workflow khud chalega (ya "Run workflow" dabayein).
4. 3-5 minute baad run ke andar **Artifacts → GK-Quiz-APK** download karein.
5. Zip khol kar `app-debug.apk` phone me install karein (Unknown sources allow karna hoga).

## Android Studio se

Folder open karein, phir **Build → Build APK(s)**.

## Questions badalna / barhana

`app/src/main/java/com/gkquiz/app/Data.kt` me `f(Cats.XXX, "sawal", "jawab")` ki lines add ya edit karein.
