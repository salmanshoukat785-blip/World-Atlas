package com.gkquiz.app

/** A sovereign country. iso = 2-letter code (used to draw the flag emoji). */
data class Country(
    val name: String,
    val iso: String,
    val capital: String,
    val currency: String,
    val assembly: String
)

/** A dependent territory / non-sovereign area listed in the sheet. */
data class Dependent(val name: String, val parent: String, val note: String = "")

class ContinentInfo(
    val name: String,
    val emoji: String,
    val countries: List<Country>,
    val dependents: List<Dependent>,
    val facts: List<Pair<String, String>>,
    val sheetCodes: List<String> = emptyList(),
    val landlocked: List<String> = emptyList()
)

/** kind = Sea / Gulf / Bay / Strait / Channel / Lagoon */
class Water(
    val name: String,
    val kind: String,
    val ocean: String,
    val continent: String,
    val where: String,
    val note: String = ""
)

class River(
    val name: String,
    val continent: String,
    val countries: String,
    val mouth: String,
    val note: String = ""
)

class Mountain(
    val name: String,
    val continent: String,
    val where: String,
    val note: String = ""
)

class RiverCities(val river: String, val continent: String, val cities: List<String>, val note: String = "")

class Org(
    val abbr: String,
    val full: String,
    val founded: String,
    val hq: String,
    val group: String,
    val extra: String = ""
)

class BoundaryLine(val name: String, val between: String, val note: String = "")

fun flagOf(iso: String): String {
    if (iso.length != 2) return "🏳️"
    val up = iso.uppercase()
    return String(Character.toChars(0x1F1E6 + (up[0] - 'A'))) +
        String(Character.toChars(0x1F1E6 + (up[1] - 'A')))
}

fun c(name: String, iso: String, capital: String, currency: String, assembly: String) =
    Country(name, iso, capital, currency, assembly)

fun d(name: String, parent: String, note: String = "") = Dependent(name, parent, note)
