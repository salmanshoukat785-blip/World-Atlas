package com.gkquiz.app

import android.content.Context
import java.util.TimeZone

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("gk", Context.MODE_PRIVATE)

    var quizzes: Int
        get() = p.getInt("quizzes", 0)
        set(v) { p.edit().putInt("quizzes", v).apply() }

    var best: Int
        get() = p.getInt("best", 0)
        set(v) { p.edit().putInt("best", v).apply() }

    var last: Int
        get() = p.getInt("last", -1)
        set(v) { p.edit().putInt("last", v).apply() }

    /** 0 = system, 1 = light, 2 = dark */
    var theme: Int
        get() = p.getInt("theme", 0)
        set(v) { p.edit().putInt("theme", v).apply() }

    var dailyGoal: Int
        get() = p.getInt("goal", 10)
        set(v) { p.edit().putInt("goal", v).apply() }

    fun known(): Set<String> = p.getStringSet("known", emptySet())!!.toSet()
    fun setKnown(s: Set<String>) { p.edit().putStringSet("known", s).apply() }

    fun bookmarks(): Set<String> = p.getStringSet("bookmarks", emptySet())!!.toSet()
    fun setBookmarks(s: Set<String>) { p.edit().putStringSet("bookmarks", s).apply() }

    fun wrong(): Set<String> = p.getStringSet("wrong", emptySet())!!.toSet()
    fun setWrong(s: Set<String>) { p.edit().putStringSet("wrong", s).apply() }

    fun lessonsDone(): Set<String> = p.getStringSet("lessonsDone", emptySet())!!.toSet()
    fun setLessonsDone(s: Set<String>) { p.edit().putStringSet("lessonsDone", s).apply() }

    fun savedItems(): Set<String> = p.getStringSet("savedItems", emptySet())!!.toSet()
    fun setSavedItems(s: Set<String>) { p.edit().putStringSet("savedItems", s).apply() }

    fun today(): Long {
        val now = System.currentTimeMillis()
        return (now + TimeZone.getDefault().getOffset(now)) / 86_400_000L
    }

    /** Call once for every question answered / card reviewed. */
    fun recordActivity() {
        val t = today()
        val l = p.getLong("lastDay", -1L)
        var s = p.getInt("streak", 0)
        var c = p.getInt("todayCount", 0)
        if (l != t) {
            s = if (l == t - 1) s + 1 else 1
            c = 0
        }
        c++
        p.edit().putLong("lastDay", t).putInt("streak", s).putInt("todayCount", c).apply()
    }

    fun currentStreak(): Int {
        val l = p.getLong("lastDay", -1L)
        return if (l < 0 || l < today() - 1) 0 else p.getInt("streak", 0)
    }

    fun todayDone(): Int =
        if (p.getLong("lastDay", -1L) == today()) p.getInt("todayCount", 0) else 0

    /** Clears progress but keeps theme and daily goal. */
    fun resetProgress() {
        val th = theme
        val g = dailyGoal
        p.edit().clear().putInt("theme", th).putInt("goal", g).apply()
    }
}
