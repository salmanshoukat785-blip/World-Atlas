package com.gkquiz.app

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Good = Color(0xFF2E7D32)
val Bad = Color(0xFFC62828)

private val LightColors = lightColorScheme(
    primary = Color(0xFF1565C0),
    secondary = Color(0xFF00897B),
    tertiary = Color(0xFFF9A825),
    background = Color(0xFFF2F6FC),
    surface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFFE3ECF8),
    primaryContainer = Color(0xFFD6E6FB),
    onPrimaryContainer = Color(0xFF0B2B55)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF90CAF9),
    secondary = Color(0xFF4DB6AC),
    tertiary = Color(0xFFFFD54F),
    background = Color(0xFF0E1621),
    surface = Color(0xFF172233),
    surfaceVariant = Color(0xFF22324A),
    primaryContainer = Color(0xFF1D3557),
    onPrimaryContainer = Color(0xFFD6E6FB)
)

@Composable
fun GKTheme(mode: Int, content: @Composable () -> Unit) {
    val dark = when (mode) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, content = content)
}
