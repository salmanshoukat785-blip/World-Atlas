@file:OptIn(ExperimentalMaterial3Api::class)

package com.gkquiz.app

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class QuizPreset(val cat: String? = null, val cont: String? = null, val mistakes: Boolean = false)

class Question(val fact: Fact, val options: List<String>)

private fun buildOptions(f: Fact): List<String> {
    f.pool?.let { p ->
        return (p.filter { it != f.a }.shuffled().take(3) + f.a).shuffled()
    }
    val sameGroup = ALL_FACTS.filter { it.cat == f.cat && it.grp == f.grp && it.a != f.a }
    val sameCont = if (f.cont.isNotEmpty()) sameGroup.filter { it.cont == f.cont }.map { it.a }.distinct() else emptyList()
    var wrong = sameCont.shuffled().take(3)
    if (wrong.size < 3) {
        wrong = (wrong + sameGroup.map { it.a }.distinct().shuffled()).distinct().take(3)
    }
    if (wrong.size < 3) {
        wrong = (wrong + ALL_FACTS.filter { it.a != f.a }.map { it.a }.distinct().shuffled()).distinct().take(3)
    }
    return (wrong + f.a).shuffled()
}

private fun makeQuestions(facts: List<Fact>, count: Int): List<Question> =
    facts.shuffled().take(count).map { Question(it, buildOptions(it)) }

private fun mistakeQuestions(store: Store): List<Question>? {
    val w = store.wrong()
    val l = makeQuestions(ALL_FACTS.filter { it.key in w }, 20)
    return if (l.isEmpty()) null else l
}

// ------------------------------------------------------------------ quiz section

@Composable
fun QuizSection(store: Store, preset: QuizPreset?) {
    val cs = MaterialTheme.colorScheme
    var cat by remember { mutableStateOf(preset?.cat) }
    var cont by remember { mutableStateOf(preset?.cont) }
    var count by remember { mutableIntStateOf(10) }
    var session by remember { mutableStateOf<List<Question>?>(if (preset?.mistakes == true) mistakeQuestions(store) else null) }
    val s = session

    if (s != null) {
        QuizRun(s, store) { session = null }
        return
    }

    val available = remember(cat, cont) { filterFacts(cat, cont) }
    val wrongCount = remember { store.wrong().size }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("📝 Quiz", Modifier.padding(horizontal = 16.dp), fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text(
            "Pick filters, then start. Questions are made from all lessons.",
            Modifier.padding(horizontal = 16.dp),
            color = cs.onBackground.copy(alpha = 0.7f)
        )

        Text("Topic", Modifier.padding(horizontal = 16.dp), fontWeight = FontWeight.SemiBold)
        ChipRow(
            options = Cats.all,
            selected = cat,
            allLabel = "All topics",
            labelOf = { c -> "${topicEmoji[c] ?: ""} $c" }
        ) { cat = it }

        Text("Continent", Modifier.padding(horizontal = 16.dp), fontWeight = FontWeight.SemiBold)
        ChipRow(options = CONT_KEYS, selected = cont, allLabel = "All continents") { cont = it }

        Text("Number of questions", Modifier.padding(horizontal = 16.dp), fontWeight = FontWeight.SemiBold)
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(10, 20, 30, 50).forEach { n ->
                FilterChip(selected = count == n, onClick = { count = n }, label = { Text("$n") })
            }
        }

        Text(
            "${available.size} questions match these filters",
            Modifier.padding(horizontal = 16.dp),
            color = if (available.isEmpty()) Bad else Good,
            fontWeight = FontWeight.SemiBold
        )
        if (available.isEmpty()) {
            Text(
                "This topic has no questions for that continent. Choose 'All continents' or another topic.",
                Modifier.padding(horizontal = 16.dp),
                fontSize = 13.sp
            )
        }

        Button(
            onClick = { session = makeQuestions(available, count) },
            enabled = available.isNotEmpty(),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
        ) { Text("Start Quiz (${minOf(count, available.size)} questions)") }

        if (wrongCount > 0) {
            OutlinedButton(
                onClick = { session = mistakeQuestions(store) },
                Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            ) { Text("🔁 Review mistakes ($wrongCount)") }
        }

        Spacer(Modifier.height(8.dp))
    }
}

@Composable
fun QuizRun(questions: List<Question>, store: Store, onExit: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var idx by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    var picked by remember { mutableStateOf<String?>(null) }
    var finished by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (finished) {
            val pct = score * 100 / questions.size
            Panel {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        if (pct >= 80) "🏆 Excellent!" else if (pct >= 60) "👍 Good job!" else "💪 Keep practicing!",
                        fontSize = 22.sp, fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(8.dp))
                    Text("$score / ${questions.size}", fontSize = 44.sp, fontWeight = FontWeight.Bold, color = cs.primary)
                    Text("$pct%", fontSize = 22.sp, color = if (pct >= 60) Good else Bad)
                }
            }
            Button(onClick = onExit, Modifier.fillMaxWidth()) { Text("New Quiz") }
        } else {
            val q = questions[idx]
            Text("Question ${idx + 1} of ${questions.size}", fontWeight = FontWeight.SemiBold)
            LinearProgressIndicator(
                progress = { (idx + 1f) / questions.size },
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                color = cs.secondary,
                trackColor = cs.surfaceVariant
            )
            Panel {
                Text("${topicEmoji[q.fact.cat] ?: ""} ${q.fact.cat}", fontSize = 12.sp, color = cs.secondary)
                Spacer(Modifier.height(4.dp))
                Text(q.fact.q, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            }
            q.options.forEach { opt ->
                val container = when {
                    picked == null -> cs.primaryContainer
                    opt == q.fact.a -> Good
                    opt == picked -> Bad
                    else -> cs.surfaceVariant
                }
                val content = when {
                    picked == null -> cs.onPrimaryContainer
                    opt == q.fact.a || opt == picked -> Color.White
                    else -> cs.onSurface.copy(alpha = 0.6f)
                }
                Button(
                    onClick = {
                        if (picked == null) {
                            picked = opt
                            val ok = opt == q.fact.a
                            if (ok) score++
                            val w = store.wrong().toMutableSet()
                            if (ok) w.remove(q.fact.key) else w.add(q.fact.key)
                            store.setWrong(w)
                            store.recordActivity()
                        }
                    },
                    Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = container, contentColor = content)
                ) { Text(opt, textAlign = TextAlign.Center, modifier = Modifier.padding(vertical = 4.dp)) }
            }
            if (picked != null) {
                Text(
                    if (picked == q.fact.a) "✅ Correct!" else "❌ Wrong. Answer: ${q.fact.a}",
                    color = if (picked == q.fact.a) Good else Bad,
                    fontWeight = FontWeight.Bold
                )
                Button(
                    onClick = {
                        if (idx + 1 < questions.size) {
                            idx++
                            picked = null
                        } else {
                            val pct = score * 100 / questions.size
                            store.quizzes = store.quizzes + 1
                            store.last = pct
                            if (pct > store.best) store.best = pct
                            finished = true
                        }
                    },
                    Modifier.fillMaxWidth()
                ) { Text(if (idx + 1 < questions.size) "Next" else "Finish") }
            }
            OutlinedButton(onClick = onExit, Modifier.fillMaxWidth()) { Text("Quit") }
        }
    }
}
