@file:OptIn(ExperimentalMaterial3Api::class)

package com.gkquiz.app

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun HomeScreen(
    store: Store,
    onOpenLesson: (Lesson) -> Unit,
    onLearnCat: (String) -> Unit,
    onQuiz: () -> Unit,
    onTest: () -> Unit,
    onMistakes: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val saved = remember { store.savedItems() }
    val wrong = remember { store.wrong() }
    val streak = remember { store.currentStreak() }
    val done = remember { store.todayDone() }
    val goal = remember { store.dailyGoal }
    val quizzes = remember { store.quizzes }
    val best = remember { store.best }
    val last = remember { store.last }
    val lessonsDone = remember { store.lessonsDone() }
    val known = remember { store.known() }
    val tip = remember { ALL_FACTS[(store.today() % ALL_FACTS.size).toInt()] }
    val nextLesson = remember { ALL_LESSONS.firstOrNull { it.id !in lessonsDone } }
    val doneCount = ALL_LESSONS.count { it.id in lessonsDone }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Box(
            Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(listOf(Color(0xFF1565C0), Color(0xFF00897B))),
                    RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp)
                )
                .padding(horizontal = 20.dp, vertical = 24.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painterResource(R.drawable.ic_logo),
                    contentDescription = "Logo",
                    modifier = Modifier.size(60.dp).clip(RoundedCornerShape(16.dp))
                )
                Column(Modifier.padding(start = 14.dp).weight(1f)) {
                    Text("World Atlas", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    Text("Learn • Quiz • Self Test", color = Color.White.copy(alpha = 0.85f))
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🔥 $streak", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("day streak", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
                }
            }
        }

        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Panel {
                Text("📚 Lessons", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Spacer(Modifier.height(4.dp))
                Text("$doneCount of ${ALL_LESSONS.size} lessons completed")
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { if (ALL_LESSONS.isEmpty()) 0f else doneCount.toFloat() / ALL_LESSONS.size },
                    modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)),
                    color = cs.secondary,
                    trackColor = cs.surfaceVariant
                )
                if (nextLesson != null) {
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = { onOpenLesson(nextLesson) }) {
                        Text("Continue: ${nextLesson.title}", maxLines = 1)
                    }
                }
            }

            Panel {
                Text("🎯 Daily goal", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Spacer(Modifier.height(4.dp))
                Text(
                    if (done >= goal) "Goal complete! Great job 🎉" else "$done of $goal questions today",
                    color = if (done >= goal) Good else cs.onSurface
                )
                Spacer(Modifier.height(10.dp))
                LinearProgressIndicator(
                    progress = { (done.toFloat() / goal).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)),
                    color = cs.tertiary,
                    trackColor = cs.surfaceVariant
                )
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile("Quizzes", quizzes.toString(), Modifier.weight(1f))
                StatTile("Best", "$best%", Modifier.weight(1f))
                StatTile("Last", if (last < 0) "-" else "$last%", Modifier.weight(1f))
                StatTile("Saved", saved.size.toString(), Modifier.weight(1f))
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = onQuiz, Modifier.weight(1f)) { Text("📝 Quiz") }
                OutlinedButton(onClick = onTest, Modifier.weight(1f)) { Text("🧠 Self Test") }
            }

            if (wrong.isNotEmpty()) {
                Panel {
                    Text("🔁 Mistakes to review", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text("${wrong.size} questions you got wrong", color = cs.onSurface.copy(alpha = 0.7f))
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = onMistakes,
                        colors = ButtonDefaults.buttonColors(containerColor = cs.tertiary, contentColor = Color.Black)
                    ) { Text("Review now") }
                }
            }

            Panel {
                Text("💡 Did you know?", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Spacer(Modifier.height(6.dp))
                Text(tip.q)
                Text(tip.a, color = cs.primary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }

            Text("Topics", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Cats.all.chunked(2).forEach { pair ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    pair.forEach { cat ->
                        val ls = ALL_LESSONS.filter { it.cat == cat }
                        val dn = ls.count { it.id in lessonsDone }
                        val qs = filterFacts(cat, null)
                        val kn = qs.count { it.key in known }
                        TopicCard(cat, dn, ls.size, kn, qs.size, Modifier.weight(1f)) { onLearnCat(cat) }
                    }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun StatTile(label: String, value: String, modifier: Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            Modifier.padding(vertical = 10.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(value, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
        }
    }
}

@Composable
private fun TopicCard(
    name: String,
    lessonsDone: Int,
    lessons: Int,
    learned: Int,
    cards: Int,
    modifier: Modifier,
    onClick: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    Card(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = cs.surface),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(topicEmoji[name] ?: "📘", fontSize = 28.sp)
            Spacer(Modifier.height(4.dp))
            Text(name, fontWeight = FontWeight.Bold)
            Text("$lessonsDone / $lessons lessons", fontSize = 12.sp, color = cs.onSurface.copy(alpha = 0.6f))
            Text("$learned / $cards cards learned", fontSize = 12.sp, color = cs.onSurface.copy(alpha = 0.6f))
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { if (lessons == 0) 0f else lessonsDone.toFloat() / lessons },
                modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                color = cs.secondary,
                trackColor = cs.surfaceVariant
            )
        }
    }
}
