@file:OptIn(ExperimentalMaterial3Api::class)

package com.gkquiz.app

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ------------------------------------------------------------------ self test

@Composable
fun SelfTestSection(store: Store) {
    var cat by remember { mutableStateOf<String?>(null) }
    var cont by remember { mutableStateOf<String?>(null) }
    var mode by remember { mutableIntStateOf(0) }
    var deck by remember { mutableStateOf<List<Fact>?>(null) }
    var empty by remember { mutableStateOf(false) }
    val d = deck

    if (d != null) {
        SelfTestRun(d, store) { deck = null }
        return
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("🧠 Self Test", Modifier.padding(horizontal = 16.dp), fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("Flip through cards and mark what you know.", Modifier.padding(horizontal = 16.dp))
        Text("Topic", Modifier.padding(horizontal = 16.dp), fontWeight = FontWeight.SemiBold)
        ChipRow(
            options = Cats.all, selected = cat, allLabel = "All topics",
            labelOf = { c -> "${topicEmoji[c] ?: ""} $c" }
        ) { cat = it; empty = false }
        Text("Continent", Modifier.padding(horizontal = 16.dp), fontWeight = FontWeight.SemiBold)
        ChipRow(options = CONT_KEYS, selected = cont, allLabel = "All continents") { cont = it; empty = false }
        Text("Cards", Modifier.padding(horizontal = 16.dp), fontWeight = FontWeight.SemiBold)
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("All", "Not learned", "★ Saved").forEachIndexed { i, label ->
                FilterChip(selected = mode == i, onClick = { mode = i; empty = false }, label = { Text(label) })
            }
        }
        Button(
            onClick = {
                val known = store.known()
                val saved = store.bookmarks()
                val l = filterFacts(cat, cont).filter {
                    when (mode) {
                        1 -> it.key !in known
                        2 -> it.key in saved
                        else -> true
                    }
                }.shuffled().take(50)
                if (l.isEmpty()) {
                    empty = true
                } else {
                    empty = false
                    deck = l
                }
            },
            Modifier.fillMaxWidth().padding(horizontal = 16.dp)
        ) { Text("Start (up to 50 cards)") }
        if (empty) {
            Text(
                "No cards match this choice. Try another topic, continent or filter.",
                Modifier.padding(horizontal = 16.dp),
                color = Bad
            )
        }
    }
}

@Composable
fun SelfTestRun(deck: List<Fact>, store: Store, onExit: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var idx by remember { mutableIntStateOf(0) }
    var revealed by remember { mutableStateOf(false) }
    var gotIt by remember { mutableIntStateOf(0) }
    var missed by remember { mutableIntStateOf(0) }
    var saved by remember { mutableStateOf(store.bookmarks()) }

    fun mark(f: Fact, knew: Boolean) {
        val k = store.known().toMutableSet()
        if (knew) { k.add(f.key); gotIt++ } else { k.remove(f.key); missed++ }
        store.setKnown(k)
        store.recordActivity()
        revealed = false
        idx++
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (idx >= deck.size) {
            Panel {
                Text("🎉 Done!", fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("I knew it: $gotIt", color = Good, fontSize = 18.sp)
                Text("Need practice: $missed", color = Bad, fontSize = 18.sp)
            }
            Button(onClick = onExit, Modifier.fillMaxWidth()) { Text("Back") }
        } else {
            val f = deck[idx]
            Text("Card ${idx + 1} of ${deck.size}", fontWeight = FontWeight.SemiBold)
            LinearProgressIndicator(
                progress = { (idx + 1f) / deck.size },
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                color = cs.secondary,
                trackColor = cs.surfaceVariant
            )
            Panel {
                Row {
                    Text(
                        "${topicEmoji[f.cat] ?: ""} ${f.cat}",
                        Modifier.weight(1f),
                        fontSize = 12.sp,
                        color = cs.secondary
                    )
                    TextButton(onClick = {
                        val s = saved.toMutableSet()
                        if (!s.add(f.key)) s.remove(f.key)
                        saved = s
                        store.setBookmarks(s)
                    }) { Text(if (f.key in saved) "★" else "☆", fontSize = 24.sp) }
                }
                Text(f.q, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                if (revealed) {
                    Spacer(Modifier.height(16.dp))
                    Text(f.a, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = cs.primary)
                }
            }
            if (!revealed) {
                Button(onClick = { revealed = true }, Modifier.fillMaxWidth()) { Text("Show answer") }
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = { mark(f, true) },
                        Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Good, contentColor = Color.White)
                    ) { Text("I knew it") }
                    Button(
                        onClick = { mark(f, false) },
                        Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Bad, contentColor = Color.White)
                    ) { Text("Need practice") }
                }
            }
            OutlinedButton(onClick = onExit, Modifier.fillMaxWidth()) { Text("Quit") }
        }
    }
}

// ------------------------------------------------------------------ settings

@Composable
fun SettingsScreen(store: Store, themeMode: Int, onTheme: (Int) -> Unit) {
    var goal by remember { mutableIntStateOf(store.dailyGoal) }
    var confirm by remember { mutableStateOf(false) }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            confirmButton = {
                TextButton(onClick = { store.resetProgress(); confirm = false }) { Text("Reset") }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } },
            title = { Text("Reset progress?") },
            text = { Text("Scores, completed lessons, learned cards, saved items, mistakes and streak will be cleared.") }
        )
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("⚙️ Settings", fontSize = 26.sp, fontWeight = FontWeight.Bold)

        Panel {
            Text("🎨 Theme", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("System", "Light", "Dark").forEachIndexed { i, label ->
                    FilterChip(selected = themeMode == i, onClick = { onTheme(i) }, label = { Text(label) })
                }
            }
        }

        Panel {
            Text("🎯 Daily goal (questions)", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(5, 10, 20, 30).forEach { n ->
                    FilterChip(
                        selected = goal == n,
                        onClick = { goal = n; store.dailyGoal = n },
                        label = { Text("$n") }
                    )
                }
            }
        }

        Panel {
            Text("📴 Offline", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Spacer(Modifier.height(4.dp))
            Text(
                "Works completely offline. No internet permission is used. " +
                    "${ALL_LESSONS.size} lessons and ${ALL_FACTS.size} quiz questions are stored inside the app."
            )
        }

        Panel {
            Text("ℹ️ About the data", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Spacer(Modifier.height(4.dp))
            Text(
                "Lessons follow your Continents & Oceans sheet. Spelling and factual mistakes in the sheet are corrected, " +
                    "and a note beside each item says where the sheet differed. Capitals, currencies and assemblies can change, " +
                    "so check current news for political changes."
            )
        }

        OutlinedButton(onClick = { confirm = true }, Modifier.fillMaxWidth()) {
            Text("Reset progress", color = Bad)
        }
        Text(
            "World Atlas • v2.0",
            Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
        )
    }
}
