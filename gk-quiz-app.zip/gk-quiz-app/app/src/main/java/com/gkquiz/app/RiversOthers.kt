package com.gkquiz.app

private fun r(cont: String, name: String, countries: String, mouth: String, note: String = "") =
    River(name, cont, countries, mouth, note)

val RIVERS_AFRICA: List<River> = listOf(
    r("Africa", "Bomu", "DR Congo, Central African Republic", "Ubangi River"),
    r("Africa", "Benue", "Nigeria, Cameroon", "Niger River"),
    r("Africa", "Congo", "Congo, DR Congo, Angola", "South Atlantic Ocean", "2nd longest in Africa"),
    r("Africa", "Jubba", "Somalia", "Indian Ocean"),
    r("Africa", "Kasai", "DR Congo, Angola", "Congo River"),
    r("Africa", "Lomami", "DR Congo", "Congo River"),
    r("Africa", "Limpopo", "South Africa, Mozambique, Zimbabwe, Botswana", "Indian Ocean"),
    r("Africa", "Nile", "Egypt, Sudan (and 9 more countries upstream)", "Mediterranean Sea", "Longest river in the world"),
    r("Africa", "White Nile", "South Sudan, Sudan", "Nile River at Khartoum"),
    r("Africa", "Blue Nile", "Ethiopia, Sudan", "Joins the White Nile at Khartoum"),
    r("Africa", "Niger", "Niger, Nigeria, Mali, Benin, Guinea", "Gulf of Guinea"),
    r("Africa", "Orange", "South Africa, Namibia, Lesotho", "South Atlantic Ocean"),
    r("Africa", "Okavango", "Botswana, Namibia, Angola", "Okavango Delta (inland delta)"),
    r("Africa", "Shebelle", "Ethiopia (and Somalia)", "Jubba River area"),
    r("Africa", "Senegal", "Senegal, Mali, Mauritania", "North Atlantic Ocean"),
    r("Africa", "Ubangi", "DR Congo, Congo", "Congo River"),
    r("Africa", "Uele", "DR Congo", "Ubangi River"),
    r("Africa", "Vaal", "South Africa", "Orange River"),
    r("Africa", "Volta", "Ghana", "Gulf of Guinea"),
    r("Africa", "Zambezi", "Zambia, Zimbabwe, Mozambique, Namibia, Angola", "Mozambique Channel")
)

val RIVERS_AUSTRALIA: List<River> = listOf(
    r("Australia", "Ashburton", "Australia", "Indian Ocean"),
    r("Australia", "Belyando", "Australia", "Coral Sea (via the Burdekin)"),
    r("Australia", "Blackwood", "Australia", "Indian Ocean"),
    r("Australia", "Cooper Creek", "Australia", "Lake Eyre"),
    r("Australia", "Clutha", "New Zealand", "South Pacific Ocean"),
    r("Australia", "Daly", "Australia", "Timor Sea"),
    r("Australia", "Diamantina", "Australia", "Lake Eyre"),
    r("Australia", "De Grey", "Australia", "Indian Ocean"),
    r("Australia", "Darling", "Australia", "Murray River"),
    r("Australia", "Fortescue", "Australia", "Indian Ocean"),
    r("Australia", "Fly", "Papua New Guinea", "Gulf of Papua (Coral Sea)", "The sheet says Australia; it is in Papua New Guinea"),
    r("Australia", "Fitzroy", "Australia", "Coral Sea"),
    r("Australia", "Flinders", "Australia", "Gulf of Carpentaria"),
    r("Australia", "Gascoyne", "Australia", "Indian Ocean"),
    r("Australia", "Glenelg", "Australia", "Indian Ocean"),
    r("Australia", "Goulburn", "Australia", "Murray River"),
    r("Australia", "Lachlan", "Australia", "Murrumbidgee River"),
    r("Australia", "Ord", "Australia", "Timor Sea"),
    r("Australia", "Paroo", "Australia", "Darling River"),
    r("Australia", "Murrumbidgee", "Australia", "Murray River"),
    r("Australia", "Mitchell", "Australia", "Gulf of Carpentaria"),
    r("Australia", "McArthur", "Australia", "Arafura Sea (Gulf of Carpentaria)"),
    r("Australia", "Murchison", "Australia", "Indian Ocean"),
    r("Australia", "Murray", "Australia", "Indian Ocean", "Longest river in Australia"),
    r("Australia", "Roper", "Australia", "Gulf of Carpentaria"),
    r("Australia", "Sepik", "Papua New Guinea", "Bismarck Sea"),
    r("Australia", "Victoria", "Australia", "Timor Sea"),
    r("Australia", "Waikato", "New Zealand", "Tasman Sea"),
    r("Australia", "Warrego", "Australia", "Darling River")
)

val RIVERS_NORTH_AMERICA: List<River> = listOf(
    r("North America", "Arkansas", "USA", "Mississippi River"),
    r("North America", "Balsas", "Mexico", "North Pacific Ocean"),
    r("North America", "Brazos", "USA", "Gulf of Mexico"),
    r("North America", "Churchill", "Canada", "Hudson Bay"),
    r("North America", "Canadian", "USA", "Arkansas River"),
    r("North America", "Colorado", "USA, Mexico", "Gulf of California (Pacific)"),
    r("North America", "Colorado (Texas)", "USA", "Gulf of Mexico"),
    r("North America", "Culiacán", "Mexico", "North Pacific Ocean (Gulf of California)"),
    r("North America", "Coco", "Honduras, Nicaragua", "Caribbean Sea", "The sheet says Gulf of Mexico"),
    r("North America", "Columbia", "USA, Canada", "North Pacific Ocean", "The sheet spells it 'Colombia'"),
    r("North America", "Fraser", "Canada", "North Pacific Ocean (Strait of Georgia)"),
    r("North America", "Fuerte", "Mexico", "Gulf of California"),
    r("North America", "Grijalva", "Mexico", "Gulf of Mexico"),
    r("North America", "Hudson", "USA", "Atlantic Ocean (New York Bay)"),
    r("North America", "Mackenzie", "Canada", "Arctic Ocean"),
    r("North America", "Motagua", "Guatemala", "Caribbean Sea (Gulf of Honduras)"),
    r("North America", "Mississippi", "USA", "Gulf of Mexico", "2nd longest in North America"),
    r("North America", "Missouri", "USA", "Mississippi River", "Longest river in North America"),
    r("North America", "Ohio", "USA", "Mississippi River"),
    r("North America", "Ottawa", "Canada", "St. Lawrence River"),
    r("North America", "Patuca", "Honduras", "Caribbean Sea"),
    r("North America", "Pánuco", "Mexico", "Gulf of Mexico"),
    r("North America", "Rio Grande", "USA, Mexico", "Gulf of Mexico"),
    r("North America", "Red River", "USA", "Mississippi River"),
    r("North America", "Snake", "USA", "Columbia River"),
    r("North America", "Santiago", "Mexico", "North Pacific Ocean"),
    r("North America", "St. Lawrence", "Canada", "Gulf of St. Lawrence"),
    r("North America", "Usumacinta", "Mexico", "Grijalva River / Gulf of Mexico"),
    r("North America", "Yukon", "Alaska (USA) and Canada", "Bering Sea"),
    r("North America", "Yaqui", "Mexico", "North Pacific Ocean (Gulf of California)")
)

val RIVERS_SOUTH_AMERICA: List<River> = listOf(
    r("South America", "Amazon", "Brazil, Peru, Colombia", "South Atlantic Ocean", "Longest in South America"),
    r("South America", "Araguaia", "Brazil", "Tocantins River"),
    r("South America", "Colorado", "Argentina", "South Atlantic Ocean (Argentine Sea)"),
    r("South America", "Japurá", "Brazil (and Colombia)", "Amazon River"),
    r("South America", "Juruá", "Brazil, Peru", "Amazon River"),
    r("South America", "Magdalena", "Colombia", "Caribbean Sea"),
    r("South America", "Negro (Brazil)", "Brazil", "Amazon River"),
    r("South America", "Negro (Argentina)", "Argentina", "South Atlantic Ocean (Argentine Sea)"),
    r("South America", "Madeira", "Brazil, Bolivia", "Amazon River"),
    r("South America", "Orinoco", "Venezuela, Colombia", "North Atlantic Ocean", "The sheet says South Atlantic; it empties into the North Atlantic"),
    r("South America", "Putumayo", "Colombia, Peru, Brazil", "Amazon River"),
    r("South America", "Purus", "Brazil, Peru", "Amazon River"),
    r("South America", "Paraná", "Argentina, Brazil, Paraguay", "Río de la Plata", "2nd longest in South America"),
    r("South America", "Paraguay", "Brazil, Bolivia, Paraguay, Argentina", "Paraná River"),
    r("South America", "São Francisco", "Brazil", "South Atlantic Ocean"),
    r("South America", "Tapajós", "Brazil", "Amazon River"),
    r("South America", "Tocantins", "Brazil", "South Atlantic Ocean"),
    r("South America", "Ucayali", "Peru", "Amazon River"),
    r("South America", "Uruguay", "Uruguay, Argentina (border river, and Brazil)", "Río de la Plata"),
    r("South America", "Xingu", "Brazil", "Amazon River")
)

val ALL_RIVERS: List<River> =
    RIVERS_ASIA + RIVERS_EUROPE + RIVERS_AFRICA + RIVERS_AUSTRALIA + RIVERS_NORTH_AMERICA + RIVERS_SOUTH_AMERICA
