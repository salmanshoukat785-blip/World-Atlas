@file:OptIn(ExperimentalMaterial3Api::class)

package com.gkquiz.app

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private const val SAVED_CHIP = "★ Saved"
private const val DONE_CHIP = "✔ Completed"

private fun itemKey(l: Lesson, i: LItem) = "${l.id}|${i.term}"

// ------------------------------------------------------------------ lesson list

@Composable
fun LearnHome(
    store: Store,
    initialCat: String?,
    onOpen: (Lesson) -> Unit
) {
    val cs = MaterialTheme.colorScheme
    var query by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf(initialCat) }
    val done = remember { store.lessonsDone() }
    var saved by remember { mutableStateOf(store.savedItems()) }

    val q = query.trim()
    val lessons = remember(cat) {
        when (cat) {
            null -> ALL_LESSONS
            DONE_CHIP -> ALL_LESSONS.filter { it.id in done }
            SAVED_CHIP -> emptyList()
            else -> ALL_LESSONS.filter { it.cat == cat }
        }
    }

    // item-level results: search text or saved filter
    val hits: List<Pair<Lesson, LItem>> = remember(q, cat, saved) {
        when {
            cat == SAVED_CHIP -> ALL_LESSONS.flatMap { l -> l.items.filter { itemKey(l, it) in saved }.map { l to it } }
            q.isNotEmpty() -> ALL_LESSONS
                .filter { cat == null || cat == DONE_CHIP || it.cat == cat }
                .flatMap { l ->
                    l.items.filter {
                        it.term.contains(q, ignoreCase = true) || it.detail.contains(q, ignoreCase = true)
                    }.map { l to it }
                }
            else -> emptyList()
        }
    }
    val showHits = q.isNotEmpty() || cat == SAVED_CHIP

    Column(Modifier.fillMaxSize()) {
        Text("📚 Learn", Modifier.padding(16.dp, 16.dp, 16.dp, 0.dp), fontSize = 26.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            label = { Text("🔍 Search countries, capitals, rivers, seas...") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(16.dp, 8.dp, 16.dp, 8.dp)
        )
        ChipRow(
            options = Cats.all + listOf(DONE_CHIP, SAVED_CHIP),
            selected = cat,
            labelOf = { c -> if (topicEmoji.containsKey(c)) "${topicEmoji[c]} $c" else c }
        ) { cat = it }

        if (showHits) {
            Text(
                "${hits.size} results",
                Modifier.padding(16.dp, 8.dp, 16.dp, 4.dp),
                fontSize = 12.sp,
                color = cs.onBackground.copy(alpha = 0.6f)
            )
            if (hits.isEmpty()) {
                Text(
                    if (cat == SAVED_CHIP) "Nothing saved yet. Open a lesson and tap ☆ on any card." else "Nothing found.",
                    Modifier.padding(24.dp)
                )
            }
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp, 4.dp, 16.dp, 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(hits, key = { itemKey(it.first, it.second) }) { pair ->
                    val l = pair.first
                    val entry = pair.second
                    ItemCard(
                        item = entry,
                        source = "${l.emoji} ${l.title}",
                        saved = itemKey(l, entry) in saved,
                        onSave = {
                            val s = saved.toMutableSet()
                            if (!s.add(itemKey(l, entry))) s.remove(itemKey(l, entry))
                            saved = s
                            store.setSavedItems(s)
                        },
                        onClick = { onOpen(l) }
                    )
                }
            }
        } else {
            if (lessons.isEmpty()) {
                Text("No lessons here yet.", Modifier.padding(24.dp))
            }
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                val rows: List<Any> = if (cat == null) {
                    lessons.groupBy { it.cat }.flatMap { (c, ls) -> listOf<Any>(c) + ls }
                } else lessons
                items(rows, key = { if (it is Lesson) it.id else "hdr-$it" }) { row ->
                    if (row is Lesson) {
                        LessonCard(row, row.id in done) { onOpen(row) }
                    } else {
                        val c = row.toString()
                        Text(
                            "${topicEmoji[c] ?: ""} $c",
                            Modifier.padding(top = 8.dp, bottom = 2.dp),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = cs.primary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LessonCard(l: Lesson, done: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = cs.surface),
        elevation = CardDefaults.cardElevation(1.dp)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(l.emoji, fontSize = 30.sp, modifier = Modifier.padding(end = 12.dp))
            Column(Modifier.weight(1f)) {
                Text(l.title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(l.subtitle, fontSize = 12.sp, color = cs.onSurface.copy(alpha = 0.65f))
                Text("${l.items.size} cards", fontSize = 11.sp, color = cs.secondary)
            }
            if (done) Text("✅", fontSize = 20.sp)
        }
    }
}

@Composable
private fun ItemCard(
    item: LItem,
    source: String,
    saved: Boolean,
    onSave: () -> Unit,
    onClick: (() -> Unit)? = null
) {
    val cs = MaterialTheme.colorScheme
    val body: @Composable () -> Unit = {
        Row(
            Modifier.padding(start = 14.dp, top = 10.dp, bottom = 10.dp, end = 4.dp),
            verticalAlignment = Alignment.Top
        ) {
            Column(Modifier.weight(1f)) {
                if (source.isNotEmpty()) {
                    Text(source, fontSize = 11.sp, color = cs.secondary, fontWeight = FontWeight.SemiBold)
                }
                Text(item.term, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(Modifier.height(2.dp))
                Text(item.detail, fontSize = 14.sp, color = cs.onSurface.copy(alpha = 0.85f))
            }
            TextButton(onClick = onSave) { Text(if (saved) "★" else "☆", fontSize = 24.sp) }
        }
    }
    if (onClick != null) {
        Card(
            onClick = onClick,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = cs.surface),
            elevation = CardDefaults.cardElevation(1.dp)
        ) { body() }
    } else {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = cs.surface),
            elevation = CardDefaults.cardElevation(1.dp)
        ) { body() }
    }
}

// ------------------------------------------------------------------ lesson detail

@Composable
fun LessonDetail(lesson: Lesson, store: Store, onBack: () -> Unit, onQuiz: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var query by remember { mutableStateOf("") }
    var tag by remember { mutableStateOf<String?>(null) }
    var done by remember { mutableStateOf(lesson.id in store.lessonsDone()) }
    var saved by remember { mutableStateOf(store.savedItems()) }

    val tags = remember { lesson.items.map { it.tag }.filter { it.isNotBlank() }.distinct() }
    val shown = remember(query, tag) {
        val q = query.trim()
        lesson.items.filter {
            (tag == null || it.tag == tag) &&
                (q.isEmpty() || it.term.contains(q, ignoreCase = true) || it.detail.contains(q, ignoreCase = true))
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(start = 4.dp, end = 16.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("← Back") }
            Column(Modifier.weight(1f)) {
                Text("${lesson.emoji} ${lesson.title}", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(lesson.subtitle, fontSize = 12.sp, color = cs.onBackground.copy(alpha = 0.6f))
            }
        }
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            label = { Text("🔍 Search in this lesson") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(16.dp, 8.dp, 16.dp, 8.dp)
        )
        if (tags.size > 1) {
            ChipRow(options = tags, selected = tag) { tag = it }
        }
        Text(
            "${shown.size} of ${lesson.items.size} cards",
            Modifier.padding(16.dp, 8.dp, 16.dp, 4.dp),
            fontSize = 12.sp,
            color = cs.onBackground.copy(alpha = 0.6f)
        )
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp, 4.dp, 16.dp, 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(shown, key = { it.term + "|" + it.tag }) { entry ->
                val k = itemKey(lesson, entry)
                ItemCard(
                    item = entry,
                    source = "",
                    saved = k in saved,
                    onSave = {
                        val s = saved.toMutableSet()
                        if (!s.add(k)) s.remove(k)
                        saved = s
                        store.setSavedItems(s)
                    }
                )
            }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                    Button(onClick = onQuiz, Modifier.fillMaxWidth()) { Text("📝 Quiz this lesson") }
                    OutlinedButton(
                        onClick = {
                            val s = store.lessonsDone().toMutableSet()
                            if (done) s.remove(lesson.id) else s.add(lesson.id)
                            store.setLessonsDone(s)
                            done = !done
                        },
                        Modifier.fillMaxWidth()
                    ) { Text(if (done) "✅ Completed (tap to undo)" else "Mark lesson as completed") }
                }
            }
        }
    }
}
