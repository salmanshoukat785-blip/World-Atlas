package com.gkquiz.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Green = Color(0xFF2E7D32)
private val Red = Color(0xFFC62828)
private val Blue = Color(0xFF1565C0)
private val Bg = Color(0xFFF4F7FB)

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("gk", Context.MODE_PRIVATE)
    var quizzes: Int
        get() = p.getInt("quizzes", 0)
        set(v) { p.edit().putInt("quizzes", v).apply() }
    var best: Int
        get() = p.getInt("best", 0)
        set(v) { p.edit().putInt("best", v).apply() }
    var last: Int
        get() = p.getInt("last", -1)
        set(v) { p.edit().putInt("last", v).apply() }
    fun known(): Set<String> = p.getStringSet("known", emptySet())!!.toSet()
    fun setKnown(s: Set<String>) { p.edit().putStringSet("known", s).apply() }
    fun reset() { p.edit().clear().apply() }
}

sealed class Screen {
    object Dashboard : Screen()
    data class Quiz(val cat: String?) : Screen()
    data class SelfTest(val cat: String?) : Screen()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = Store(this)
        setContent {
            MaterialTheme {
                var screen by remember { mutableStateOf<Screen>(Screen.Dashboard) }
                var tick by remember { mutableIntStateOf(0) }
                BackHandler(enabled = screen !is Screen.Dashboard) {
                    screen = Screen.Dashboard
                }
                Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding()) {
                    when (val s = screen) {
                        is Screen.Dashboard -> DashboardScreen(
                            store = store,
                            tick = tick,
                            onQuiz = { screen = Screen.Quiz(it) },
                            onSelfTest = { screen = Screen.SelfTest(it) },
                            onReset = { store.reset(); tick++ }
                        )
                        is Screen.Quiz -> QuizScreen(
                            cat = s.cat,
                            store = store,
                            onExit = { tick++; screen = Screen.Dashboard }
                        )
                        is Screen.SelfTest -> SelfTestScreen(
                            cat = s.cat,
                            store = store,
                            onExit = { tick++; screen = Screen.Dashboard }
                        )
                    }
                }
            }
        }
    }
}

private fun factsFor(cat: String?): List<Fact> =
    if (cat == null) ALL_FACTS else ALL_FACTS.filter { it.cat == cat }

@Composable
fun DashboardScreen(
    store: Store,
    tick: Int,
    onQuiz: (String?) -> Unit,
    onSelfTest: (String?) -> Unit,
    onReset: () -> Unit
) {
    val known = remember(tick) { store.known() }
    val quizzes = remember(tick) { store.quizzes }
    val best = remember(tick) { store.best }
    val last = remember(tick) { store.last }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("GK Quiz", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Blue)
        Text("Continents, Oceans, Rivers & Organizations", color = Color.Gray)

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatCard("Quizzes", quizzes.toString(), Modifier.weight(1f))
            StatCard("Best", "$best%", Modifier.weight(1f))
            StatCard("Last", if (last < 0) "-" else "$last%", Modifier.weight(1f))
        }
        val total = ALL_FACTS.size
        val knownCount = ALL_FACTS.count { it.key in known }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Self Test progress", fontWeight = FontWeight.SemiBold)
                Text("$knownCount of $total cards learned", fontSize = 20.sp, color = Green)
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { onQuiz(null) }, Modifier.weight(1f)) { Text("Quiz: All") }
            OutlinedButton(onClick = { onSelfTest(null) }, Modifier.weight(1f)) { Text("Self Test: All") }
        }

        Text("Categories", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Cats.all.forEach { c ->
            val list = factsFor(c)
            val k = list.count { it.key in known }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Text(c, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text("$k / ${list.size} learned", color = Color.Gray)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { onQuiz(c) }) { Text("Quiz") }
                        OutlinedButton(onClick = { onSelfTest(c) }) { Text("Self Test") }
                    }
                }
            }
        }
        TextButton2("Reset progress", onReset)
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun TextButton2(label: String, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, Modifier.fillMaxWidth()) { Text(label, color = Red) }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier) {
    Card(modifier) {
        Column(Modifier.padding(12.dp).fillMaxWidth(), horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
            Text(value, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Blue)
            Text(label, color = Color.Gray)
        }
    }
}

private data class Question(val fact: Fact, val options: List<String>)

private fun buildOptions(f: Fact): List<String> {
    var wrong = ALL_FACTS.filter { it.cat == f.cat && it.a != f.a }
        .map { it.a }.distinct().shuffled().take(3)
    if (wrong.size < 3) {
        wrong = (wrong + ALL_FACTS.filter { it.a != f.a }.map { it.a }.distinct().shuffled())
            .distinct().take(3)
    }
    return (wrong + f.a).shuffled()
}

@Composable
fun QuizScreen(cat: String?, store: Store, onExit: () -> Unit) {
    val questions = remember {
        factsFor(cat).shuffled().take(10).map { Question(it, buildOptions(it)) }
    }
    var idx by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    var picked by remember { mutableStateOf<String?>(null) }
    var finished by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Quiz - ${cat ?: "All"}", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Blue)

        if (finished) {
            val pct = if (questions.isEmpty()) 0 else score * 100 / questions.size
            Card(Modifier.fillMaxWidth()) {
                Column(
                    Modifier.padding(24.dp).fillMaxWidth(),
                    horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally
                ) {
                    Text("Score", color = Color.Gray)
                    Text("$score / ${questions.size}", fontSize = 40.sp, fontWeight = FontWeight.Bold)
                    Text("$pct%", fontSize = 24.sp, color = if (pct >= 60) Green else Red)
                }
            }
            Button(onClick = onExit, Modifier.fillMaxWidth()) { Text("Back to Dashboard") }
        } else if (questions.isNotEmpty()) {
            val q = questions[idx]
            Text("Question ${idx + 1} of ${questions.size}", color = Color.Gray)
            Card(Modifier.fillMaxWidth()) {
                Text(q.fact.q, Modifier.padding(16.dp), fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            }
            q.options.forEach { opt ->
                val color = when {
                    picked == null -> Blue
                    opt == q.fact.a -> Green
                    opt == picked -> Red
                    else -> Color.Gray
                }
                Button(
                    onClick = {
                        if (picked == null) {
                            picked = opt
                            if (opt == q.fact.a) score++
                        }
                    },
                    Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = color)
                ) { Text(opt, textAlign = TextAlign.Center) }
            }
            if (picked != null) {
                Text(
                    if (picked == q.fact.a) "Correct!" else "Wrong. Answer: ${q.fact.a}",
                    color = if (picked == q.fact.a) Green else Red,
                    fontWeight = FontWeight.Bold
                )
                Button(
                    onClick = {
                        if (idx + 1 < questions.size) {
                            idx++
                            picked = null
                        } else {
                            val pct = score * 100 / questions.size
                            store.quizzes = store.quizzes + 1
                            store.last = pct
                            if (pct > store.best) store.best = pct
                            finished = true
                        }
                    },
                    Modifier.fillMaxWidth()
                ) { Text(if (idx + 1 < questions.size) "Next" else "Finish") }
            }
            OutlinedButton(onClick = onExit, Modifier.fillMaxWidth()) { Text("Quit") }
        }
    }
}

@Composable
fun SelfTestScreen(cat: String?, store: Store, onExit: () -> Unit) {
    val deck = remember { factsFor(cat).shuffled() }
    var idx by remember { mutableIntStateOf(0) }
    var revealed by remember { mutableStateOf(false) }
    var gotIt by remember { mutableIntStateOf(0) }
    var missed by remember { mutableIntStateOf(0) }

    fun mark(f: Fact, knew: Boolean) {
        val k = store.known().toMutableSet()
        if (knew) { k.add(f.key); gotIt++ } else { k.remove(f.key); missed++ }
        store.setKnown(k)
        revealed = false
        idx++
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Self Test - ${cat ?: "All"}", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Blue)

        if (idx >= deck.size) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    Text("Done!", fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    Text("I knew it: $gotIt", color = Green, fontSize = 18.sp)
                    Text("Need practice: $missed", color = Red, fontSize = 18.sp)
                }
            }
            Button(onClick = onExit, Modifier.fillMaxWidth()) { Text("Back to Dashboard") }
        } else {
            val f = deck[idx]
            Text("Card ${idx + 1} of ${deck.size}", color = Color.Gray)
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    Text(f.q, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                    if (revealed) {
                        Spacer(Modifier.height(16.dp))
                        Text(f.a, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Green)
                    }
                }
            }
            if (!revealed) {
                Button(onClick = { revealed = true }, Modifier.fillMaxWidth()) { Text("Show answer") }
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { mark(f, true) },
                        Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Green)
                    ) { Text("I knew it") }
                    Button(
                        onClick = { mark(f, false) },
                        Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Red)
                    ) { Text("Need practice") }
                }
            }
            OutlinedButton(onClick = onExit, Modifier.fillMaxWidth()) { Text("Quit") }
        }
    }
}
