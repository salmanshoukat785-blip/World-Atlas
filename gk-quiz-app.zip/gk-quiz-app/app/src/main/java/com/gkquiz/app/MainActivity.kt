package com.gkquiz.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = Store(this)
        setContent {
            var themeMode by remember { mutableIntStateOf(store.theme) }
            GKTheme(themeMode) {
                AppRoot(store, themeMode) {
                    themeMode = it
                    store.theme = it
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppRoot(store: Store, themeMode: Int, onTheme: (Int) -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    var keyN by remember { mutableIntStateOf(0) }
    var learnCat by remember { mutableStateOf<String?>(null) }
    var openLesson by remember { mutableStateOf<Lesson?>(null) }
    var quizPreset by remember { mutableStateOf<QuizPreset?>(null) }

    val tabs = listOf("🏠" to "Home", "📚" to "Learn", "📝" to "Quiz", "🧠" to "Test", "⚙️" to "Settings")

    fun go(t: Int) {
        tab = t
        keyN++
    }

    BackHandler(enabled = tab != 0 || openLesson != null) {
        if (openLesson != null) {
            openLesson = null
            keyN++
        } else {
            learnCat = null
            quizPreset = null
            go(0)
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = {
                            learnCat = null
                            quizPreset = null
                            openLesson = null
                            go(i)
                        },
                        icon = { Text(t.first, fontSize = 20.sp) },
                        label = { Text(t.second, fontSize = 11.sp) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            key(tab, keyN) {
                when (tab) {
                    0 -> HomeScreen(
                        store = store,
                        onOpenLesson = { l -> openLesson = l; go(1) },
                        onLearnCat = { c -> learnCat = c; openLesson = null; go(1) },
                        onQuiz = { quizPreset = null; go(2) },
                        onTest = { go(3) },
                        onMistakes = { quizPreset = QuizPreset(mistakes = true); go(2) }
                    )
                    1 -> {
                        val l = openLesson
                        if (l != null) {
                            LessonDetail(
                                lesson = l,
                                store = store,
                                onBack = { openLesson = null; keyN++ },
                                onQuiz = {
                                    quizPreset = QuizPreset(cat = l.quizCat, cont = l.quizCont)
                                    openLesson = null
                                    go(2)
                                }
                            )
                        } else {
                            LearnHome(store, learnCat) { picked -> openLesson = picked; keyN++ }
                        }
                    }
                    2 -> QuizSection(store, quizPreset)
                    3 -> SelfTestSection(store)
                    else -> SettingsScreen(store, themeMode, onTheme)
                }
            }
        }
    }
}
