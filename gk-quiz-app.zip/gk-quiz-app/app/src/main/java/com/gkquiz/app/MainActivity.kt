@file:OptIn(ExperimentalMaterial3Api::class)

package com.gkquiz.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private const val SAVED = "★ Saved"

private val topicEmoji = mapOf(
    Cats.CONT to "🌍",
    Cats.ORG to "🏛️",
    Cats.RIVER to "🏞️",
    Cats.SEA to "🌊",
    Cats.MTN to "⛰️",
    Cats.LINE to "🗺️",
    Cats.CITY to "🏙️"
)

private fun factsFor(cat: String?): List<Fact> =
    if (cat == null) ALL_FACTS else ALL_FACTS.filter { it.cat == cat }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = Store(this)
        setContent {
            var themeMode by remember { mutableIntStateOf(store.theme) }
            GKTheme(themeMode) {
                AppRoot(store, themeMode) {
                    themeMode = it
                    store.theme = it
                }
            }
        }
    }
}

@Composable
fun AppRoot(store: Store, themeMode: Int, onTheme: (Int) -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    var keyN by remember { mutableIntStateOf(0) }
    var learnCat by remember { mutableStateOf<String?>(null) }
    var quizMistakes by remember { mutableStateOf(false) }

    val tabs = listOf("🏠" to "Home", "📚" to "Learn", "📝" to "Quiz", "🧠" to "Test", "⚙️" to "Settings")

    BackHandler(enabled = tab != 0) {
        tab = 0
        keyN++
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = {
                            learnCat = null
                            quizMistakes = false
                            tab = i
                            keyN++
                        },
                        icon = { Text(t.first, fontSize = 20.sp) },
                        label = { Text(t.second, fontSize = 11.sp) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            key(tab, keyN) {
                when (tab) {
                    0 -> DashboardScreen(
                        store = store,
                        onTopic = { c -> learnCat = c; tab = 1; keyN++ },
                        onQuiz = { quizMistakes = false; tab = 2; keyN++ },
                        onTest = { tab = 3; keyN++ },
                        onMistakes = { quizMistakes = true; tab = 2; keyN++ }
                    )
                    1 -> LearnScreen(store, learnCat)
                    2 -> QuizTab(store, quizMistakes)
                    3 -> SelfTestTab(store)
                    else -> SettingsScreen(store, themeMode, onTheme)
                }
            }
        }
    }
}

// ------------------------------------------------------------------ shared UI

@Composable
fun Panel(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(Modifier.padding(16.dp)) { content() }
    }
}

@Composable
fun TopicChips(selected: String?, extras: List<String> = emptyList(), onSelect: (String?) -> Unit) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        FilterChip(selected = selected == null, onClick = { onSelect(null) }, label = { Text("All") })
        extras.forEach { e ->
            FilterChip(selected = selected == e, onClick = { onSelect(e) }, label = { Text(e) })
        }
        Cats.all.forEach { c ->
            FilterChip(
                selected = selected == c,
                onClick = { onSelect(c) },
                label = { Text("${topicEmoji[c] ?: ""} $c") }
            )
        }
    }
}

// ------------------------------------------------------------------ dashboard

@Composable
fun DashboardScreen(
    store: Store,
    onTopic: (String) -> Unit,
    onQuiz: () -> Unit,
    onTest: () -> Unit,
    onMistakes: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val known = remember { store.known() }
    val saved = remember { store.bookmarks() }
    val wrong = remember { store.wrong() }
    val streak = remember { store.currentStreak() }
    val done = remember { store.todayDone() }
    val goal = remember { store.dailyGoal }
    val quizzes = remember { store.quizzes }
    val best = remember { store.best }
    val last = remember { store.last }
    val tip = remember { ALL_FACTS[(store.today() % ALL_FACTS.size).toInt()] }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Box(
            Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(listOf(Color(0xFF1565C0), Color(0xFF00897B))),
                    RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp)
                )
                .padding(horizontal = 20.dp, vertical = 24.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painterResource(R.drawable.ic_logo),
                    contentDescription = "Logo",
                    modifier = Modifier.size(60.dp).clip(RoundedCornerShape(16.dp))
                )
                Column(Modifier.padding(start = 14.dp).weight(1f)) {
                    Text("World Atlas", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    Text("GK • Geography • Quiz", color = Color.White.copy(alpha = 0.85f))
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🔥 $streak", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("day streak", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
                }
            }
        }

        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Panel {
                Text("🎯 Daily goal", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Spacer(Modifier.height(4.dp))
                Text(
                    if (done >= goal) "Goal complete! Great job 🎉" else "$done of $goal questions today",
                    color = if (done >= goal) Good else cs.onSurface
                )
                Spacer(Modifier.height(10.dp))
                LinearProgressIndicator(
                    progress = { (done.toFloat() / goal).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)),
                    color = cs.secondary,
                    trackColor = cs.surfaceVariant
                )
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile("Quizzes", quizzes.toString(), Modifier.weight(1f))
                StatTile("Best", "$best%", Modifier.weight(1f))
                StatTile("Last", if (last < 0) "-" else "$last%", Modifier.weight(1f))
                StatTile("Saved", saved.size.toString(), Modifier.weight(1f))
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = onQuiz, Modifier.weight(1f)) { Text("📝 Start Quiz") }
                OutlinedButton(onClick = onTest, Modifier.weight(1f)) { Text("🧠 Self Test") }
            }

            if (wrong.isNotEmpty()) {
                Panel {
                    Text("🔁 Mistakes to review", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text("${wrong.size} questions you got wrong", color = cs.onSurface.copy(alpha = 0.7f))
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = onMistakes,
                        colors = ButtonDefaults.buttonColors(containerColor = cs.tertiary, contentColor = Color.Black)
                    ) { Text("Review now") }
                }
            }

            Panel {
                Text("💡 Did you know?", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Spacer(Modifier.height(6.dp))
                Text(tip.q)
                Text(tip.a, color = cs.primary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }

            Text("Topics", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Cats.all.chunked(2).forEach { pair ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    pair.forEach { c ->
                        val list = factsFor(c)
                        val k = list.count { it.key in known }
                        TopicCard(c, k, list.size, Modifier.weight(1f)) { onTopic(c) }
                    }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun StatTile(label: String, value: String, modifier: Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            Modifier.padding(vertical = 10.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(value, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
        }
    }
}

@Composable
private fun TopicCard(name: String, learned: Int, total: Int, modifier: Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Card(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = cs.surface),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(topicEmoji[name] ?: "📘", fontSize = 28.sp)
            Spacer(Modifier.height(4.dp))
            Text(name, fontWeight = FontWeight.Bold)
            Text("$learned / $total learned", fontSize = 12.sp, color = cs.onSurface.copy(alpha = 0.6f))
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { if (total == 0) 0f else learned.toFloat() / total },
                modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                color = cs.secondary,
                trackColor = cs.surfaceVariant
            )
        }
    }
}

// ------------------------------------------------------------------ learn

@Composable
fun LearnScreen(store: Store, initialCat: String?) {
    var query by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf(initialCat) }
    var saved by remember { mutableStateOf(store.bookmarks()) }
    val known = remember { store.known() }

    val list = remember(query, cat, saved) {
        ALL_FACTS.filter { f ->
            val catOk = when (cat) {
                null -> true
                SAVED -> f.key in saved
                else -> f.cat == cat
            }
            val q = query.trim()
            catOk && (q.isEmpty() || f.q.contains(q, ignoreCase = true) || f.a.contains(q, ignoreCase = true))
        }
    }

    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            label = { Text("🔍 Search topics, rivers, countries...") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(16.dp, 16.dp, 16.dp, 8.dp)
        )
        TopicChips(selected = cat, extras = listOf(SAVED)) { cat = it }
        Text(
            "${list.size} items",
            Modifier.padding(16.dp, 8.dp, 16.dp, 4.dp),
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
        )
        if (list.isEmpty()) {
            Text(
                if (cat == SAVED) "No saved items yet. Tap ☆ on any card to save it." else "Nothing found.",
                Modifier.padding(24.dp)
            )
        }
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp, 4.dp, 16.dp, 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(list, key = { it.key }) { f ->
                FactCard(f, f.key in saved, f.key in known) {
                    val s = saved.toMutableSet()
                    if (!s.add(f.key)) s.remove(f.key)
                    saved = s
                    store.setBookmarks(s)
                }
            }
        }
    }
}

@Composable
fun FactCard(f: Fact, saved: Boolean, learned: Boolean, onSave: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = cs.surface),
        elevation = CardDefaults.cardElevation(1.dp)
    ) {
        Row(Modifier.padding(start = 14.dp, top = 10.dp, bottom = 10.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("${topicEmoji[f.cat] ?: ""} ${f.cat}", fontSize = 11.sp, color = cs.secondary, fontWeight = FontWeight.SemiBold)
                Text(f.q, fontWeight = FontWeight.SemiBold)
                Text(f.a, color = cs.primary, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            }
            if (learned) Text("✅", Modifier.padding(end = 2.dp))
            TextButton(onClick = onSave) { Text(if (saved) "★" else "☆", fontSize = 26.sp) }
        }
    }
}

// ------------------------------------------------------------------ quiz

class Question(val fact: Fact, val options: List<String>)

private fun buildOptions(f: Fact): List<String> {
    var wrong = ALL_FACTS.filter { it.cat == f.cat && it.a != f.a }
        .map { it.a }.distinct().shuffled().take(3)
    if (wrong.size < 3) {
        wrong = (wrong + ALL_FACTS.filter { it.a != f.a }.map { it.a }.distinct().shuffled())
            .distinct().take(3)
    }
    return (wrong + f.a).shuffled()
}

private fun makeQuestions(facts: List<Fact>, count: Int): List<Question> =
    facts.shuffled().take(count).map { Question(it, buildOptions(it)) }

private fun mistakeQuestions(store: Store): List<Question>? {
    val w = store.wrong()
    val l = makeQuestions(ALL_FACTS.filter { it.key in w }, 20)
    return if (l.isEmpty()) null else l
}

@Composable
fun QuizTab(store: Store, startMistakes: Boolean) {
    var cat by remember { mutableStateOf<String?>(null) }
    var count by remember { mutableIntStateOf(10) }
    var session by remember { mutableStateOf(if (startMistakes) mistakeQuestions(store) else null) }
    val s = session

    if (s != null) {
        QuizRun(s, store) { session = null }
        return
    }

    val wrongCount = remember { store.wrong().size }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("📝 Quiz", Modifier.padding(horizontal = 16.dp), fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("Choose a topic", Modifier.padding(horizontal = 16.dp), fontWeight = FontWeight.SemiBold)
        TopicChips(selected = cat) { cat = it }
        Text("Number of questions", Modifier.padding(horizontal = 16.dp), fontWeight = FontWeight.SemiBold)
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(10, 20, 30).forEach { n ->
                FilterChip(selected = count == n, onClick = { count = n }, label = { Text("$n") })
            }
        }
        Button(
            onClick = { session = makeQuestions(factsFor(cat), count) },
            Modifier.fillMaxWidth().padding(horizontal = 16.dp)
        ) { Text("Start Quiz") }
        if (wrongCount > 0) {
            OutlinedButton(
                onClick = { session = mistakeQuestions(store) },
                Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            ) { Text("🔁 Review mistakes ($wrongCount)") }
        }
    }
}

@Composable
fun QuizRun(questions: List<Question>, store: Store, onExit: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var idx by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    var picked by remember { mutableStateOf<String?>(null) }
    var finished by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (finished) {
            val pct = score * 100 / questions.size
            Panel {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        if (pct >= 80) "🏆 Excellent!" else if (pct >= 60) "👍 Good job!" else "💪 Keep practicing!",
                        fontSize = 22.sp, fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(8.dp))
                    Text("$score / ${questions.size}", fontSize = 44.sp, fontWeight = FontWeight.Bold, color = cs.primary)
                    Text("$pct%", fontSize = 22.sp, color = if (pct >= 60) Good else Bad)
                }
            }
            Button(onClick = onExit, Modifier.fillMaxWidth()) { Text("New Quiz") }
        } else {
            val q = questions[idx]
            Text("Question ${idx + 1} of ${questions.size}", fontWeight = FontWeight.SemiBold)
            LinearProgressIndicator(
                progress = { (idx + 1f) / questions.size },
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                color = cs.secondary,
                trackColor = cs.surfaceVariant
            )
            Panel {
                Text("${topicEmoji[q.fact.cat] ?: ""} ${q.fact.cat}", fontSize = 12.sp, color = cs.secondary)
                Spacer(Modifier.height(4.dp))
                Text(q.fact.q, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            }
            q.options.forEach { opt ->
                val container = when {
                    picked == null -> cs.primaryContainer
                    opt == q.fact.a -> Good
                    opt == picked -> Bad
                    else -> cs.surfaceVariant
                }
                val content = when {
                    picked == null -> cs.onPrimaryContainer
                    opt == q.fact.a || opt == picked -> Color.White
                    else -> cs.onSurface.copy(alpha = 0.6f)
                }
                Button(
                    onClick = {
                        if (picked == null) {
                            picked = opt
                            val ok = opt == q.fact.a
                            if (ok) score++
                            val w = store.wrong().toMutableSet()
                            if (ok) w.remove(q.fact.key) else w.add(q.fact.key)
                            store.setWrong(w)
                            store.recordActivity()
                        }
                    },
                    Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = container, contentColor = content)
                ) { Text(opt, textAlign = TextAlign.Center, modifier = Modifier.padding(vertical = 4.dp)) }
            }
            if (picked != null) {
                Text(
                    if (picked == q.fact.a) "✅ Correct!" else "❌ Wrong. Answer: ${q.fact.a}",
                    color = if (picked == q.fact.a) Good else Bad,
                    fontWeight = FontWeight.Bold
                )
                Button(
                    onClick = {
                        if (idx + 1 < questions.size) {
                            idx++
                            picked = null
                        } else {
                            val pct = score * 100 / questions.size
                            store.quizzes = store.quizzes + 1
                            store.last = pct
                            if (pct > store.best) store.best = pct
                            finished = true
                        }
                    },
                    Modifier.fillMaxWidth()
                ) { Text(if (idx + 1 < questions.size) "Next" else "Finish") }
            }
            OutlinedButton(onClick = onExit, Modifier.fillMaxWidth()) { Text("Quit") }
        }
    }
}

// ------------------------------------------------------------------ self test

@Composable
fun SelfTestTab(store: Store) {
    var cat by remember { mutableStateOf<String?>(null) }
    var mode by remember { mutableIntStateOf(0) }
    var deck by remember { mutableStateOf<List<Fact>?>(null) }
    var empty by remember { mutableStateOf(false) }
    val d = deck

    if (d != null) {
        SelfTestRun(d, store) { deck = null }
        return
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("🧠 Self Test", Modifier.padding(horizontal = 16.dp), fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("Flip through cards and mark what you know.", Modifier.padding(horizontal = 16.dp))
        Text("Topic", Modifier.padding(horizontal = 16.dp), fontWeight = FontWeight.SemiBold)
        TopicChips(selected = cat) { cat = it; empty = false }
        Text("Cards", Modifier.padding(horizontal = 16.dp), fontWeight = FontWeight.SemiBold)
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("All", "Not learned", "★ Saved").forEachIndexed { i, label ->
                FilterChip(selected = mode == i, onClick = { mode = i; empty = false }, label = { Text(label) })
            }
        }
        Button(
            onClick = {
                val known = store.known()
                val saved = store.bookmarks()
                val l = factsFor(cat).filter {
                    when (mode) {
                        1 -> it.key !in known
                        2 -> it.key in saved
                        else -> true
                    }
                }.shuffled()
                if (l.isEmpty()) {
                    empty = true
                } else {
                    empty = false
                    deck = l
                }
            },
            Modifier.fillMaxWidth().padding(horizontal = 16.dp)
        ) { Text("Start") }
        if (empty) {
            Text(
                "No cards match this choice. Try another topic or filter.",
                Modifier.padding(horizontal = 16.dp),
                color = Bad
            )
        }
    }
}

@Composable
fun SelfTestRun(deck: List<Fact>, store: Store, onExit: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var idx by remember { mutableIntStateOf(0) }
    var revealed by remember { mutableStateOf(false) }
    var gotIt by remember { mutableIntStateOf(0) }
    var missed by remember { mutableIntStateOf(0) }
    var saved by remember { mutableStateOf(store.bookmarks()) }

    fun mark(f: Fact, knew: Boolean) {
        val k = store.known().toMutableSet()
        if (knew) { k.add(f.key); gotIt++ } else { k.remove(f.key); missed++ }
        store.setKnown(k)
        store.recordActivity()
        revealed = false
        idx++
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (idx >= deck.size) {
            Panel {
                Text("🎉 Done!", fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("I knew it: $gotIt", color = Good, fontSize = 18.sp)
                Text("Need practice: $missed", color = Bad, fontSize = 18.sp)
            }
            Button(onClick = onExit, Modifier.fillMaxWidth()) { Text("Back") }
        } else {
            val f = deck[idx]
            Text("Card ${idx + 1} of ${deck.size}", fontWeight = FontWeight.SemiBold)
            LinearProgressIndicator(
                progress = { (idx + 1f) / deck.size },
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                color = cs.secondary,
                trackColor = cs.surfaceVariant
            )
            Panel {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "${topicEmoji[f.cat] ?: ""} ${f.cat}",
                        Modifier.weight(1f),
                        fontSize = 12.sp,
                        color = cs.secondary
                    )
                    TextButton(onClick = {
                        val s = saved.toMutableSet()
                        if (!s.add(f.key)) s.remove(f.key)
                        saved = s
                        store.setBookmarks(s)
                    }) { Text(if (f.key in saved) "★" else "☆", fontSize = 24.sp) }
                }
                Text(f.q, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                if (revealed) {
                    Spacer(Modifier.height(16.dp))
                    Text(f.a, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = cs.primary)
                }
            }
            if (!revealed) {
                Button(onClick = { revealed = true }, Modifier.fillMaxWidth()) { Text("Show answer") }
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = { mark(f, true) },
                        Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Good, contentColor = Color.White)
                    ) { Text("I knew it") }
                    Button(
                        onClick = { mark(f, false) },
                        Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Bad, contentColor = Color.White)
                    ) { Text("Need practice") }
                }
            }
            OutlinedButton(onClick = onExit, Modifier.fillMaxWidth()) { Text("Quit") }
        }
    }
}

// ------------------------------------------------------------------ settings

@Composable
fun SettingsScreen(store: Store, themeMode: Int, onTheme: (Int) -> Unit) {
    var goal by remember { mutableIntStateOf(store.dailyGoal) }
    var confirm by remember { mutableStateOf(false) }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            confirmButton = {
                TextButton(onClick = { store.resetProgress(); confirm = false }) { Text("Reset") }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } },
            title = { Text("Reset progress?") },
            text = { Text("Scores, learned cards, saved items, mistakes and streak will be cleared.") }
        )
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("⚙️ Settings", fontSize = 26.sp, fontWeight = FontWeight.Bold)

        Panel {
            Text("🎨 Theme", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("System", "Light", "Dark").forEachIndexed { i, label ->
                    FilterChip(selected = themeMode == i, onClick = { onTheme(i) }, label = { Text(label) })
                }
            }
        }

        Panel {
            Text("🎯 Daily goal (questions)", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(5, 10, 20, 30).forEach { n ->
                    FilterChip(
                        selected = goal == n,
                        onClick = { goal = n; store.dailyGoal = n },
                        label = { Text("$n") }
                    )
                }
            }
        }

        Panel {
            Text("📴 Offline", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Spacer(Modifier.height(4.dp))
            Text("This app works completely offline. No internet permission is used, and all ${ALL_FACTS.size} cards are stored inside the app.")
        }

        OutlinedButton(onClick = { confirm = true }, Modifier.fillMaxWidth()) {
            Text("Reset progress", color = Bad)
        }
        Text(
            "World Atlas • v1.1",
            Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
        )
    }
}
