package com.gkquiz.app

val CONTINENTS: List<ContinentInfo> = listOf(
    ContinentInfo(
        name = "Asia", emoji = "🌏",
        countries = ASIA_COUNTRIES, dependents = ASIA_DEPENDENT,
        facts = listOf(
            "Rank" to "Largest continent by area and population",
            "Countries" to "${ASIA_COUNTRIES.size} sovereign states listed here (sheet: 48 + 3 dependent; Russia and Turkey also touch Europe)",
            "Highest point" to "Mount Everest, 8,848.86 m (Nepal–China)",
            "Lowest point" to "Dead Sea shore (about 430 m below sea level)",
            "Longest river" to "Yangtze (China)",
            "Oceans" to "Pacific, Indian and Arctic",
            "Organizations" to "SAARC (8 Dec 1985, Kathmandu), ASEAN (8 Aug 1967, Jakarta), SCO, OIC, ADB",
            "Sheet note" to "The sheet's Asia list leaves out Oman; it is added here"
        ),
        sheetCodes = listOf("VERY-QG = 1", "JUN-L = 2", "PACK = 3", "MB = 4", "TSI = 5"),
        landlocked = listOf(
            "Afghanistan", "Armenia", "Azerbaijan", "Bhutan", "Kazakhstan", "Kyrgyzstan",
            "Laos", "Mongolia", "Nepal", "Tajikistan", "Turkmenistan", "Uzbekistan"
        )
    ),
    ContinentInfo(
        name = "Europe", emoji = "🌍",
        countries = EUROPE_COUNTRIES, dependents = EUROPE_DEPENDENT,
        facts = listOf(
            "Rank" to "Second smallest continent (about 10.2 million km²)",
            "Countries" to "${EUROPE_COUNTRIES.size} sovereign states (sheet: 44 + 4 dependent)",
            "Highest point" to "Mount Elbrus, 5,642 m (Russia, Caucasus)",
            "Longest river" to "Volga (Russia); Danube is 2nd longest",
            "Largest country" to "Russia",
            "Smallest country" to "Vatican City (Holy See)",
            "Boundary with Asia" to "Ural Mountains",
            "Organizations" to "EU (1 Nov 1993, Brussels, 27 members), NATO, Council of Europe",
            "Sheet note" to "G7+1 = Canada, Italy, France, USA, UK, Japan, Russia, Germany (Russia suspended since 2014)"
        ),
        sheetCodes = listOf("DE = 1", "H-PRF-GCU = 2", "NAI = 3", "BML = 4", "S = 7", "EU members: HARDMEN = 1, BIG-PF = 2, LC = 3, S = 4"),
        landlocked = listOf(
            "Andorra", "Austria", "Belarus", "Czech Republic", "Hungary", "Liechtenstein", "Luxembourg",
            "Moldova", "North Macedonia", "San Marino", "Serbia", "Slovakia", "Switzerland", "Vatican City"
        )
    ),
    ContinentInfo(
        name = "Africa", emoji = "🌍",
        countries = AFRICA_COUNTRIES, dependents = AFRICA_DEPENDENT,
        facts = listOf(
            "Rank" to "Second largest continent (about 30.3 million km²)",
            "Countries" to "${AFRICA_COUNTRIES.size} sovereign states (sheet: 54 + 4 dependent)",
            "Highest point" to "Mount Kilimanjaro, 5,895 m (Tanzania)",
            "Longest river" to "Nile; Congo is 2nd longest",
            "Largest country" to "Algeria",
            "Smallest country" to "Seychelles",
            "Largest hot desert" to "Sahara",
            "Organizations" to "African Union (9 Jul 2002, Addis Ababa, 55 members, 6 languages)"
        ),
        sheetCodes = listOf("KRUNT-L = 1", "BSC-E = 1", "MALTESE-DZN = 2", "CBC = 3", "SMG = 5"),
        landlocked = listOf(
            "Botswana", "Burkina Faso", "Burundi", "Central African Republic", "Chad", "Eswatini", "Ethiopia",
            "Lesotho", "Malawi", "Mali", "Niger", "Rwanda", "South Sudan", "Uganda", "Zambia", "Zimbabwe"
        )
    ),
    ContinentInfo(
        name = "North America", emoji = "🌎",
        countries = NA_COUNTRIES, dependents = NA_DEPENDENT,
        facts = listOf(
            "Rank" to "Third largest continent (about 24.7 million km²)",
            "Countries" to "${NA_COUNTRIES.size} sovereign states (sheet header says 23 + 26 dependent)",
            "Highest point" to "Denali (Mount McKinley), 6,190 m, Alaska",
            "Longest river" to "Missouri; Mississippi is 2nd longest",
            "Largest country" to "Canada",
            "Largest mountain range" to "Rocky Mountains",
            "Organizations" to "USMCA (successor of NAFTA); the sheet's 'NAU: Canada, Mexico, USA' is not a real organization",
            "Landlocked" to "None"
        ),
        sheetCodes = listOf("PEANUT-MJ = 1", "DG-H = 2", "BCS = 3", "Dependent: PUT-F = 1, GAN = 2, MCB = 3, S = 7"),
        landlocked = emptyList()
    ),
    ContinentInfo(
        name = "South America", emoji = "🌎",
        countries = SA_COUNTRIES, dependents = SA_DEPENDENT,
        facts = listOf(
            "Rank" to "Fourth largest continent (about 17.8 million km²)",
            "Countries" to "${SA_COUNTRIES.size} sovereign states (+ French Guiana and Falkland Islands = the sheet's 14)",
            "Highest point" to "Aconcagua, 6,961 m (Argentina)",
            "Longest river" to "Amazon",
            "Largest country" to "Brazil",
            "Longest mountain range" to "Andes (also longest on Earth)",
            "Landlocked" to "Bolivia and Paraguay",
            "Organizations" to "USAN / UNASUR = Union of South American Nations (sheet: founded 8 Dec 2004, HQ Quito, 5 members)",
            "Capitals note" to "Bolivia has two capitals: Sucre and La Paz"
        ),
        sheetCodes = listOf("GAVE-US = 1", "PCB-F = 2"),
        landlocked = listOf("Bolivia", "Paraguay")
    ),
    ContinentInfo(
        name = "Australia / Oceania", emoji = "🌏",
        countries = OCEANIA_COUNTRIES, dependents = OCEANIA_DEPENDENT,
        facts = listOf(
            "Rank" to "Smallest continent by land area",
            "Countries" to "${OCEANIA_COUNTRIES.size} sovereign states + 12 dependent territories (the sheet's '23' is a typo for 14 + 12)",
            "Largest country" to "Australia",
            "Highest point (Oceania)" to "Puncak Jaya, 4,884 m (Indonesian New Guinea); Mount Kosciuszko 2,228 m is the highest on mainland Australia",
            "Longest river" to "Murray (Australia)",
            "Mountain system" to "Great Dividing Range",
            "Landlocked" to "None"
        ),
        sheetCodes = listOf("GK-CV-W = 1", "MAP-FS = 2", "T = 3", "N = 5"),
        landlocked = emptyList()
    ),
    ContinentInfo(
        name = "Antarctica", emoji = "🧊",
        countries = emptyList(), dependents = emptyList(),
        facts = listOf(
            "Rank" to "Fifth largest continent (about 14.2 million km²)",
            "Population" to "No permanent population, only research stations",
            "Highest point" to "Vinson Massif, 4,892 m",
            "Climate" to "Coldest, driest and windiest continent",
            "Surrounding ocean" to "Southern Ocean",
            "Treaty" to "Antarctic Treaty (1959)",
            "Claims (sheet)" to "UK: South Orkney Islands, South Shetland Islands, South Georgia, South Sandwich Islands",
            "Claims (sheet) 2" to "Norway: Peter I Island, Bouvet Island",
            "Claims (sheet) 3" to "Australia: Heard and McDonald Islands",
            "Claims (sheet) 4" to "New Zealand: Scott Island, Balleny Islands",
            "Also claimants" to "Argentina, Chile and France (missing from the sheet)",
            "Mountain range" to "Prince Charles Mountains"
        ),
        sheetCodes = emptyList(), landlocked = emptyList()
    )
)

val ALL_COUNTRIES: List<Pair<String, Country>> =
    CONTINENTS.flatMap { ci -> ci.countries.map { ci.name to it } }
