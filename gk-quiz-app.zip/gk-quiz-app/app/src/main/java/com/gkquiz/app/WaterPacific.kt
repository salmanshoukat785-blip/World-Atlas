package com.gkquiz.app

private fun w(name: String, kind: String, ocean: String, cont: String, where: String, note: String = "") =
    Water(name, kind, ocean, cont, where, note)

private const val P = "Pacific"

val WATER_PACIFIC: List<Water> = listOf(
    // ---------------- North Pacific ----------------
    w("Bering Sea", "Sea", P, "Asia / North America", "Russia and Alaska (USA)", "North Pacific. Near the International Date Line"),
    w("Bohai Sea", "Sea", P, "Asia", "East China, joins the Yellow Sea", "North Pacific"),
    w("Celebes Sea", "Sea", P, "Asia", "Philippines and North Sulawesi (Indonesia)", "North Pacific"),
    w("East China Sea", "Sea", P, "Asia", "China and Taiwan", "North Pacific"),
    w("Sea of Japan", "Sea", P, "Asia", "Japan, Russia and Korea", "North Pacific. Important fishing area"),
    w("Sea of Okhotsk", "Sea", P, "Asia", "Russia and Japan", "North Pacific"),
    w("Philippine Sea", "Sea", P, "Asia", "Japan, Taiwan and Philippines", "North Pacific. Largest sea by length (about 5,000 miles per sheet)"),
    w("Sulu Sea", "Sea", P, "Asia", "Philippines and Palawan Islands", "North Pacific"),
    w("Salish Sea", "Sea", P, "North America", "USA and Canada", "North Pacific"),
    w("South China Sea", "Sea", P, "Asia", "Vietnam and Philippines", "North Pacific. Largest sea in the world by area"),
    w("Yellow Sea", "Sea", P, "Asia", "Korea and China", "North Pacific"),
    w("Gulf of Alaska", "Gulf", P, "North America", "Alaska Peninsula (USA)", "North Pacific Ocean"),
    w("Gulf of California", "Gulf", P, "North America", "Mexico (and California coast)", "North Pacific Ocean"),
    w("Gulf of Thailand", "Gulf", P, "Asia", "Cambodia and Thailand", "Part of the South China Sea"),
    w("Gulf of Anadyr", "Gulf", P, "Asia", "East Russia", "Part of the Bering Sea, near the International Date Line"),
    w("Bay of Korea", "Bay", P, "Asia", "China and North Korea"),
    w("Bashi Channel", "Strait", P, "Asia", "Taiwan and Batanes Islands (Philippines)"),
    w("Hainan Strait", "Strait", P, "Asia", "Hainan Island and Zhanjiang (China)"),
    w("Johor Strait", "Strait", P, "Asia", "Between Malaysia and Singapore"),
    w("Korean Strait", "Strait", P, "Asia", "South Korea and Japan", "Links the East China Sea and the Sea of Japan"),
    w("Singapore Strait", "Strait", P, "Asia", "Links the South China Sea and the Malacca Strait"),
    w("Tartar Strait", "Strait", P, "Asia", "Sakhalin Island and mainland Russia", "Links the Sea of Okhotsk and the Sea of Japan (sheet says 'Oshkosh')"),
    w("Taiwan Strait", "Strait", P, "Asia", "China and Taiwan", "Links the East and South China Seas"),
    w("Tsugaru Strait", "Strait", P, "Asia", "Japan (Honshu and Hokkaido)", "Links the Sea of Japan and the North Pacific"),
    w("Tablas Strait", "Strait", P, "Asia", "Mindoro and Panay islands (Philippines)"),
    w("San Bernardino Strait", "Strait", P, "Asia", "Philippines", "Links the Philippine Sea with the Samar Sea"),

    // ---------------- South Pacific ----------------
    w("Arafura Sea", "Sea", P, "Australia / Asia", "Australia and Papua New Guinea", "South Pacific"),
    w("Banda Sea", "Sea", P, "Asia", "Indonesia (Maluku)", "South Pacific"),
    w("Bali Sea", "Sea", P, "Asia", "North of Bali, between Java and Flores Sea (Indonesia)", "South Pacific"),
    w("Bismarck Sea", "Sea", P, "Australia", "Papua New Guinea and New Britain", "South Pacific"),
    w("Chilean Sea", "Sea", P, "South America", "Chile's coast", "South Pacific"),
    w("Ceram Sea", "Sea", P, "Asia", "Maluku and Maloló, Indonesia", "South Pacific"),
    w("Coral Sea", "Sea", P, "Australia", "East of Australia", "South Pacific"),
    w("Flores Sea", "Sea", P, "Asia", "Between Java and Banda Sea (Indonesia)", "South Pacific"),
    w("Java Sea", "Sea", P, "Asia", "Between Java and Kalimantan (Indonesia)", "South Pacific"),
    w("Molucca Sea", "Sea", P, "Asia", "Maluku Islands (Indonesia)", "South Pacific"),
    w("Mar de Grau", "Sea", P, "South America", "Along the coast of Peru", "South Pacific"),
    w("Savu Sea", "Sea", P, "Asia", "West of Timor (Indonesia)", "South Pacific"),
    w("Solomon Sea", "Sea", P, "Australia", "Papua New Guinea and Solomon Islands", "South Pacific"),
    w("Timor Sea", "Sea", P, "Asia / Australia", "Timor island and Australia (Indonesia)", "South Pacific"),
    w("Tasman Sea", "Sea", P, "Australia", "Australia and New Zealand", "South Pacific"),
    w("Gulf of Carpentaria", "Gulf", P, "Australia", "North Australia", "Opens into the Arafura Sea"),
    w("Cook Strait", "Strait", P, "Australia", "North and South Islands of New Zealand", "Links the Tasman Sea and the South Pacific"),
    w("Bass Strait", "Strait", P, "Australia", "Victoria and Tasmania (Australia)", "Links the Tasman Sea and the Indian Ocean"),
    w("Bali Strait", "Strait", P, "Asia", "Bali and Java (Indonesia)", "Links the Bali Sea and the Indian Ocean"),
    w("Lombok Strait", "Strait", P, "Asia", "Bali and Lombok (Indonesia)", "Links the Bali Sea and the Indian Ocean"),
    w("Macassar Strait", "Strait", P, "Asia", "Sulawesi and Kalimantan (Indonesia)", "Links the Celebes and Java Seas"),
    w("Sunda Strait", "Strait", P, "Asia", "Java and Sumatra (Indonesia)", "Links the Java Sea and the Indian Ocean"),
    w("Torres Strait", "Strait", P, "Australia", "Australia and Papua New Guinea", "Links the Arafura and Coral Seas"),
    w("Sumba Strait", "Strait", P, "Asia", "Sumba and Sunda islands (Indonesia)", "Links the Savu Sea and the Indian Ocean")
)
